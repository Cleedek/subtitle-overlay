// Runs in every page and frame. Finds the video, draws the subtitle layer on
// top of it and keeps it in sync with the video's own clock.
(function () {
  'use strict';
  if (window.__subOverlay) return;

  const { SubLib, SubSettings, SubRender } = globalThis;

  let settings = Object.assign({}, SubSettings.DEFAULTS);
  let cues = [];          // loaded subtitle lines, sorted by start (ms)
  let file = null;        // { name, b64, encoding, usedEncoding } of the loaded file
  let stashed = null;     // previous subtitles after a video swap, for "Restore"
  let video = null;       // the video the overlay follows
  let pinned = null;      // video chosen by hand in the popup
  let visible = true;     // Alt + S
  let tabHasSubs = false; // some frame in this tab has subtitles (for shortcut forwarding)
  let lastSrc = '';
  let lastAdAt = 0;
  let lastKey = '';
  let lastGeom = '';
  let raf = 0;
  let watchTimer = 0;
  let bareFullscreen = false;
  let ownFullscreen = null; // { container, videoStyle } while our own fullscreen is on

  // ---------- storage ----------

  SubSettings.load().then((s) => { settings = s; refreshStyle(); });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.settings) return;
    settings = Object.assign({}, SubSettings.DEFAULTS, changes.settings.newValue || {});
    refreshStyle();
  });

  const pageKey = () => 'page:' + location.href;

  async function rememberFile() {
    try {
      await chrome.storage.session.set({ [pageKey()]: Object.assign({ t: Date.now() }, file) });
      // Keep only the 20 most recent pages so session storage stays small.
      const all = await chrome.storage.session.get(null);
      const pages = Object.keys(all).filter((k) => k.startsWith('page:')).sort((a, b) => all[b].t - all[a].t);
      if (pages.length > 20) await chrome.storage.session.remove(pages.slice(20));
    } catch (e) { /* session storage unavailable; reload just won't restore */ }
  }

  function send(msg) {
    try { return chrome.runtime.sendMessage(msg).catch(() => {}); } catch (e) { return Promise.resolve(); }
  }

  // ---------- finding videos ----------

  // All <video> elements in this frame, including inside open shadow roots.
  function findVideos() {
    const found = [...document.querySelectorAll('video')];
    const walk = (rootNode) => {
      const all = rootNode.querySelectorAll('*');
      for (const el of all) {
        if (!el.shadowRoot) continue;
        found.push(...el.shadowRoot.querySelectorAll('video'));
        walk(el.shadowRoot);
      }
    };
    walk(document);
    return [...new Set(found)];
  }

  function area(v) {
    const r = v.getBoundingClientRect();
    if (r.width < 50 || r.height < 50) return 0;
    const st = getComputedStyle(v);
    if (st.visibility === 'hidden' || st.display === 'none' || +st.opacity === 0) return 0;
    return r.width * r.height;
  }

  const isPlaying = (v) => !v.paused && !v.ended && v.readyState > 2;

  // Pinned video first, then the largest playing one, then the largest visible one.
  function pickVideo() {
    if (pinned && pinned.isConnected) return pinned;
    const vids = findVideos().map((v) => ({ v, a: area(v) })).filter((x) => x.a > 0);
    if (!vids.length) return null;
    const playing = vids.filter((x) => isPlaying(x.v));
    const pool = playing.length ? playing : vids;
    pool.sort((a, b) => b.a - a.a);
    return pool[0].v;
  }

  // ---------- overlay DOM ----------

  let host, shadow, subsEl, toastEl, hintEl, fsBtn, dropEl, foundEl;

  function ensureHost() {
    if (host) return;
    host = document.createElement('subtitle-overlay-root');
    const hs = host.style;
    for (const [k, v] of Object.entries({
      all: 'initial', position: 'fixed', left: '0px', top: '0px', width: '0px', height: '0px',
      'z-index': '2147483647', 'pointer-events': 'none', display: 'block', overflow: 'visible',
      contain: 'layout style',
    })) hs.setProperty(k, v, 'important');
    shadow = host.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = SubRender.CSS + `
      :host { all: initial; }
      .toast, .hint, .fs, .drop { font: 600 14px/1.3 system-ui, -apple-system, "Segoe UI", sans-serif; color: #fff; }
      .toast {
        position: absolute; top: 10%; left: 50%; transform: translateX(-50%);
        background: rgba(20,20,20,.85); padding: 6px 12px; border-radius: 999px;
        opacity: 0; transition: opacity .2s; white-space: nowrap; pointer-events: none;
      }
      .toast.on { opacity: 1; }
      .hint {
        position: absolute; top: 12px; left: 50%; transform: translateX(-50%);
        display: none; align-items: center; gap: 8px; pointer-events: auto;
        background: rgba(20,20,20,.9); padding: 6px 6px 6px 12px; border-radius: 10px; white-space: nowrap;
      }
      .hint.on { display: flex; }
      .hint button, .fs {
        font: inherit; color: #fff; background: rgba(255,255,255,.16); border: 0;
        border-radius: 7px; padding: 4px 10px; cursor: pointer;
      }
      .hint button:hover, .fs:hover { background: rgba(255,255,255,.28); }
      /* Top centre: players rarely put their own controls there. */
      .fs {
        position: absolute; top: 12px; left: 50%; transform: translateX(-50%); display: none; pointer-events: auto;
        background: rgba(20,20,20,.75); font-size: 13px; white-space: nowrap;
      }
      .fs.on { display: block; }
      .hint.on ~ .fs { display: none; } /* the "New video" hint uses the same spot */
      .drop {
        position: absolute; inset: 8px; border: 3px dashed rgba(255,255,255,.9); border-radius: 12px;
        background: rgba(0,0,0,.45); display: none; align-items: center; justify-content: center; font-size: 20px;
      }
      .drop.on { display: flex; }
      .found {
        position: absolute; top: 12px; right: 12px; display: none; flex-direction: column; gap: 6px;
        pointer-events: auto; max-width: min(420px, calc(100% - 24px));
        background: rgba(20,20,20,.92); padding: 10px 10px 10px 12px; border-radius: 12px;
        font: 600 13px/1.3 system-ui, -apple-system, "Segoe UI", sans-serif; color: #fff;
      }
      .found.on { display: flex; }
      .found-head { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
      .found-row { display: flex; align-items: center; gap: 6px; }
      .found-name { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-weight: 500; opacity: .85; }
      .found-lang { font-size: 11px; text-transform: uppercase; background: #6d28d9; border-radius: 5px; padding: 1px 6px; }
      .found button {
        font: inherit; color: #fff; background: rgba(255,255,255,.16); border: 0;
        border-radius: 7px; padding: 4px 10px; cursor: pointer; white-space: nowrap;
      }
      .found button:hover { background: rgba(255,255,255,.28); }
      .found button.main { background: #7c3aed; }
      .found button.main:hover { background: #8b5cf6; }
      .found .x { background: transparent; padding: 2px 6px; }
      .found-msg { display: flex; flex-direction: column; align-items: flex-start; gap: 6px; font-weight: 500; font-size: 12px; }
      .found-msg > span { opacity: .85; }
      .found-msg .saved::before { content: "\\2713"; color: #86efac; font-weight: 700; margin-right: 6px; }
    `;
    subsEl = el('div', 'subs');
    toastEl = el('div', 'toast');
    hintEl = el('div', 'hint');
    hintEl.append(el('span', '', 'New video. Load subtitles for it?'));
    const restore = el('button', '', 'Restore previous');
    restore.addEventListener('click', restoreStashed);
    const close = el('button', '', '×');
    close.title = 'Dismiss';
    close.addEventListener('click', () => { stashed = null; hintEl.classList.remove('on'); });
    hintEl.append(restore, close);
    fsBtn = el('button', 'fs', '⛶ Fullscreen with subtitles (Alt+F)');
    fsBtn.addEventListener('click', (e) => { e.stopPropagation(); toggleFullscreen(); });
    dropEl = el('div', 'drop', 'Drop .srt or .vtt subtitles here');
    foundEl = el('div', 'found');
    shadow.append(style, subsEl, toastEl, hintEl, fsBtn, dropEl, foundEl);
    placeHost();
    useFont();
  }

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text) n.textContent = text;
    return n;
  }

  // Puts the overlay where it can be seen: inside the fullscreen element when
  // the site's player container is fullscreen, otherwise at the page root.
  function placeHost() {
    if (!host) return;
    const fe = document.fullscreenElement;
    let parent = document.documentElement;
    if (fe && video && fe !== video && containsDeep(fe, video)) {
      const root = video.getRootNode();
      parent = root instanceof ShadowRoot && containsDeep(fe, root.host) && fe.shadowRoot ? root : fe;
    }
    if (host.parentNode !== parent) parent.appendChild(host);
  }

  // Like Node.contains, but also looks through shadow roots.
  function containsDeep(ancestor, node) {
    let n = node;
    while (n) {
      if (n === ancestor) return true;
      n = n.parentNode || (n instanceof ShadowRoot ? n.host : null);
    }
    return false;
  }

  let toastTimer = 0;
  function toast(text) {
    ensureHost();
    toastEl.textContent = text;
    toastEl.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('on'), 1500);
    position(true);
  }

  // ---------- geometry ----------

  // Box of the actual picture inside the video element (without letterbox bars).
  function pictureRect(v) {
    const r = v.getBoundingClientRect();
    const vw = v.videoWidth, vh = v.videoHeight;
    const fit = getComputedStyle(v).objectFit;
    if (!vw || !vh || fit === 'fill' || fit === 'cover') return { left: r.left, top: r.top, width: r.width, height: r.height };
    const k = Math.min(r.width / vw, r.height / vh);
    const w = vw * k, h = vh * k;
    return { left: r.left + (r.width - w) / 2, top: r.top + (r.height - h) / 2, width: w, height: h };
  }

  function position(force) {
    if (!host || !video) return;
    const r = pictureRect(video);
    const geom = [r.left, r.top, r.width, r.height].map(Math.round).join(',');
    if (!force && geom === lastGeom) return;
    lastGeom = geom;
    const hs = host.style;
    hs.setProperty('left', Math.round(r.left) + 'px', 'important');
    hs.setProperty('top', Math.round(r.top) + 'px', 'important');
    hs.setProperty('width', Math.round(r.width) + 'px', 'important');
    hs.setProperty('height', Math.round(r.height) + 'px', 'important');
    SubRender.applyStyle(subsEl, settings, r.height, r.width);
  }

  function refreshStyle() {
    if (!subsEl) return;
    useFont();
    position(true);
    render(true);
  }

  // A Google font is only downloaded once the overlay is actually used on a page.
  function useFont() {
    if (!SubRender.isGoogle(settings.font)) return;
    SubRender.ensureFont(document, settings.font)
      .then(() => position(true))
      .catch(() => toast('Font "' + SubRender.googleName(settings.font) + '" could not load'));
  }

  // ---------- timing ----------

  // Cues active at time t (ms). Binary search, then look back for overlaps.
  function activeAt(t) {
    let lo = 0, hi = cues.length - 1, last = -1;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (cues[mid].start <= t) { last = mid; lo = mid + 1; } else hi = mid - 1;
    }
    const out = [];
    for (let i = last; i >= 0 && last - i < 30; i--) if (cues[i].end > t) out.push(i);
    return out.reverse();
  }

  // YouTube marks its player with .ad-showing while an ad plays in the same video.
  function inAd() {
    const ad = !!(video && video.closest && video.closest('.ad-showing'));
    if (ad) lastAdAt = Date.now();
    return ad;
  }

  function render(force) {
    if (!subsEl || !video) return;
    let idx = [];
    const hide = !visible || !cues.length || inAd() || (video.paused && settings.onPause === 'hide');
    if (!hide) idx = activeAt(video.currentTime * 1000 - settings.offset);
    const key = idx.join(',');
    if (!force && key === lastKey) return;
    lastKey = key;
    SubRender.renderCues(subsEl, idx.map((i) => cues[i]));
  }

  function tick() {
    raf = 0;
    position(false);
    render(false);
    if (video && cues.length && !video.paused && !video.ended) raf = requestAnimationFrame(tick);
  }

  function kick() {
    if (!raf) raf = requestAnimationFrame(tick);
  }

  // ---------- attaching to a video ----------

  const VIDEO_EVENTS = ['play', 'playing', 'pause', 'seeking', 'seeked', 'ratechange', 'timeupdate', 'loadedmetadata'];
  let resizeObs = null;

  function attach(v) {
    if (video === v) return;
    detachVideo();
    video = v;
    lastSrc = v.currentSrc || v.src || '';
    for (const ev of VIDEO_EVENTS) v.addEventListener(ev, kick);
    v.addEventListener('loadstart', onSourceChange);
    v.addEventListener('emptied', onSourceChange);
    resizeObs = new ResizeObserver(() => position(false));
    resizeObs.observe(v);
    ensureHost();
    placeHost();
    lastKey = '';
    position(true);
    kick();
  }

  function detachVideo() {
    if (!video) return;
    for (const ev of VIDEO_EVENTS) video.removeEventListener(ev, kick);
    video.removeEventListener('loadstart', onSourceChange);
    video.removeEventListener('emptied', onSourceChange);
    if (resizeObs) resizeObs.disconnect();
    resizeObs = null;
    video = null;
  }

  // While subtitles are loaded: once a second, check the video still exists
  // and still plays the same thing (single-page sites swap videos without reloading).
  function startWatch() {
    if (watchTimer) return;
    watchTimer = setInterval(() => {
      if (!cues.length && !stashed && !restorePending) return stopWatch();
      if (restorePending) return tryRestore();
      if (!video || !video.isConnected) {
        const next = pickVideo();
        if (next) {
          const sameSrc = (next.currentSrc || next.src) === lastSrc;
          attach(next);
          if (!sameSrc) onSourceChange();
        }
        return;
      }
      if ((video.currentSrc || video.src || '') !== lastSrc) onSourceChange();
      inAd();
    }, 1000);
  }

  function stopWatch() {
    clearInterval(watchTimer);
    watchTimer = 0;
  }

  function onSourceChange() {
    if (!video) return;
    const src = video.currentSrc || video.src || '';
    if (!src || src === lastSrc) return;
    lastSrc = src;
    // Ads in the same element change the source too; don't drop subtitles for them.
    if (inAd() || Date.now() - lastAdAt < 5000) return;
    if (!cues.length) return;
    stashed = { cues, file };
    clearSubs(true);
    ensureHost();
    hintEl.classList.add('on');
    setTimeout(() => hintEl && hintEl.classList.remove('on'), 10000);
  }

  function restoreStashed() {
    if (!stashed) return;
    cues = stashed.cues;
    file = stashed.file;
    stashed = null;
    hintEl.classList.remove('on');
    afterLoad();
  }

  // ---------- loading ----------

  function loadBytes(name, b64, encoding, targetVideo) {
    const bytes = SubLib.base64ToBytes(b64);
    const { text, encoding: used } = SubLib.decode(bytes, encoding || 'auto');
    const parsed = SubLib.parse(text);
    if (!parsed.length) return { ok: false, error: 'No subtitle lines found in this file.' };
    const v = targetVideo || pickVideo();
    if (!v) return { ok: false, error: 'No video found on this page.' };
    cues = parsed;
    file = { name, b64, encoding: encoding || 'auto', usedEncoding: used };
    stashed = null;
    if (hintEl) hintEl.classList.remove('on');
    attach(v);
    afterLoad();
    rememberFile();
    toast('Loaded ' + parsed.length + ' lines' + (settings.offset ? ' · Sync: ' + fmtOffset(settings.offset) : ''));
    return { ok: true, count: parsed.length, encoding: used };
  }

  function afterLoad() {
    visible = true;
    lastKey = '';
    startWatch();
    enableMouse(true);
    position(true);
    render(true);
    kick();
    send({ type: 'subs-state', has: true });
  }

  function clearSubs(keepStash) {
    cues = [];
    file = null;
    if (!keepStash) stashed = null;
    lastKey = '';
    if (subsEl) subsEl.replaceChildren();
    enableMouse(false);
    if (fsBtn) fsBtn.classList.remove('on');
    send({ type: 'subs-state', has: false });
  }

  // Restore the last file loaded on this exact page (after a reload).
  let restorePending = null;
  async function checkSessionRestore() {
    try {
      const key = pageKey();
      const got = await chrome.storage.session.get(key);
      if (got[key]) { restorePending = got[key]; startWatch(); tryRestore(); }
    } catch (e) { /* no session access */ }
  }
  function tryRestore() {
    if (!restorePending) return;
    const v = pickVideo();
    if (!v) return;
    const f = restorePending;
    restorePending = null;
    loadBytes(f.name, f.b64, f.encoding, v);
  }

  // ---------- fullscreen ----------

  document.addEventListener('fullscreenchange', () => {
    const fe = document.fullscreenElement;
    if (ownFullscreen && fe !== ownFullscreen.container) {
      video && (video.style.cssText = ownFullscreen.videoStyle);
      ownFullscreen = null;
    }
    if (!video || !cues.length) return;
    if (fe === video) bareFullscreen = true;
    else if (!fe && bareFullscreen) {
      bareFullscreen = false;
      setTimeout(() => toast('This site’s fullscreen hides subtitles. Use Alt+F instead.'), 300);
    }
    placeHost();
    position(true);
    render(true);
  });

  // Our own fullscreen: the video's parent element plus the overlay inside it.
  async function toggleFullscreen() {
    if (!video) return;
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(() => {});
      return;
    }
    const container = video.parentElement || (video.getRootNode() instanceof ShadowRoot ? video.getRootNode().host : null);
    if (!container) return;
    const videoStyle = video.style.cssText;
    try {
      await container.requestFullscreen();
      ownFullscreen = { container, videoStyle };
      for (const [k, v] of Object.entries({
        position: 'absolute', inset: '0', width: '100%', height: '100%', 'max-width': 'none',
        'max-height': 'none', 'object-fit': 'contain', transform: 'none', margin: '0',
      })) video.style.setProperty(k, v, 'important');
      fsBtn.classList.remove('on');
    } catch (e) {
      toast('Click the video once, then press Alt+F');
    }
  }

  // Show the fullscreen button briefly when the mouse moves over the video.
  let fsTimer = 0, mouseQueued = false;
  function onMouseMove(e) {
    if (mouseQueued || !video || !fsBtn || document.fullscreenElement) return;
    mouseQueued = true;
    requestAnimationFrame(() => {
      mouseQueued = false;
      const r = video.getBoundingClientRect();
      const inside = e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom;
      if (!inside) return;
      fsBtn.classList.add('on');
      clearTimeout(fsTimer);
      fsTimer = setTimeout(() => fsBtn.classList.remove('on'), 2000);
    });
  }
  function enableMouse(on) {
    document[on ? 'addEventListener' : 'removeEventListener']('mousemove', onMouseMove, { passive: true, capture: true });
  }

  // When paused, the loop is off, so follow layout changes from these events.
  window.addEventListener('resize', () => cues.length && position(true));
  window.addEventListener('scroll', () => cues.length && position(false), { capture: true, passive: true });

  // ---------- keyboard ----------

  function isTyping(e) {
    const t = e.composedPath ? e.composedPath()[0] : e.target;
    if (!t || !t.tagName) return false;
    if (t.isContentEditable) return true;
    if (t.tagName === 'TEXTAREA' || t.tagName === 'SELECT') return true;
    if (t.tagName === 'INPUT') return !/^(button|checkbox|radio|range|submit|reset|color|file|image)$/i.test(t.type);
    return false;
  }

  // Physical keys (event.code), so Option on a Mac doesn't change the match.
  function actionFor(e) {
    if (!e.altKey || e.ctrlKey || e.metaKey) return null;
    switch (e.code) {
      case 'BracketLeft': return { kind: 'offset', delta: e.shiftKey ? -1000 : -100 };
      case 'BracketRight': return { kind: 'offset', delta: e.shiftKey ? 1000 : 100 };
      case 'Digit0': return e.shiftKey ? null : { kind: 'offset-reset' };
      case 'KeyS': return e.shiftKey ? null : { kind: 'toggle' };
      case 'ArrowUp': return e.shiftKey ? null : { kind: 'move', delta: 10 };
      case 'ArrowDown': return e.shiftKey ? null : { kind: 'move', delta: -10 };
      case 'KeyF': return e.shiftKey ? null : { kind: 'fullscreen' };
      default: return null;
    }
  }

  window.addEventListener('keydown', (e) => {
    if (e.repeat && e.code === 'KeyF') return;
    const action = actionFor(e);
    if (!action || isTyping(e)) return;
    if (cues.length) runAction(action);
    else if (tabHasSubs) send({ type: 'forward-key', action });
    else return;
    e.preventDefault();
    e.stopImmediatePropagation();
  }, true);

  function fmtOffset(ms) {
    return (ms > 0 ? '+' : ms < 0 ? '−' : '') + (Math.abs(ms) / 1000).toFixed(1) + ' s';
  }

  async function runAction(a) {
    if (a.kind === 'offset' || a.kind === 'offset-reset') {
      // Update locally first so fast repeated presses add up before the save lands.
      settings.offset = SubSettings.clamp('offset', a.kind === 'offset' ? settings.offset + a.delta : 0);
      SubSettings.save({ offset: settings.offset });
      toast('Sync: ' + fmtOffset(settings.offset));
      render(true);
    } else if (a.kind === 'toggle') {
      visible = !visible;
      render(true);
      toast(visible ? 'Subtitles on' : 'Subtitles off');
    } else if (a.kind === 'move') {
      settings.bottom = SubSettings.clamp('bottom', settings.bottom + a.delta);
      SubSettings.save({ bottom: settings.bottom });
      position(true);
      toast('Position: ' + settings.bottom + ' px');
    } else if (a.kind === 'fullscreen') {
      toggleFullscreen();
    }
  }

  // ---------- drag and drop ----------

  function videoAt(x, y) {
    return findVideos().find((v) => {
      const r = v.getBoundingClientRect();
      return r.width > 50 && x >= r.left && x <= r.right && y >= r.top && y <= r.bottom;
    });
  }

  let dropVideo = null;
  document.addEventListener('dragover', (e) => {
    if (!e.dataTransfer || ![...e.dataTransfer.types].includes('Files')) return;
    const v = videoAt(e.clientX, e.clientY);
    if (!v) return hideDrop();
    e.preventDefault();
    e.stopPropagation();
    e.dataTransfer.dropEffect = 'copy';
    if (dropVideo !== v) {
      dropVideo = v;
      if (video !== v) { if (!cues.length) attach(v); }
      ensureHost();
      dropEl.classList.add('on');
      position(true);
    }
  }, true);
  document.addEventListener('dragleave', (e) => { if (!e.relatedTarget) hideDrop(); }, true);
  function hideDrop() {
    dropVideo = null;
    if (dropEl) dropEl.classList.remove('on');
  }

  document.addEventListener('drop', async (e) => {
    if (!dropVideo) return;
    const v = dropVideo;
    hideDrop();
    e.preventDefault();
    e.stopPropagation();
    const f = e.dataTransfer.files[0];
    if (!f || !/\.(srt|vtt)$/i.test(f.name)) return toast('Drop an .srt or .vtt file');
    const bytes = new Uint8Array(await f.arrayBuffer());
    pinned = v;
    const res = loadBytes(f.name, SubLib.bytesToBase64(bytes), 'auto', v);
    if (!res.ok) toast(res.error);
  }, true);

  // ---------- "Subtitles found" card ----------

  // Subtitle files the page just loaded (seen by the background worker),
  // offered with one-click buttons right on the video.
  // The card waits until you actually watch something: a video playing with
  // sound. Feeds like Reddit preload and autoplay muted previews, whose
  // subtitle tracks would otherwise pop up while you only scroll. Files seen
  // more than a minute before that are dropped (they belong to other posts).
  const found = [];
  const waiting = []; // { item, t }
  let foundTimer = 0;
  const WAIT_MS = 60000;

  const watched = () => findVideos().find((v) => isPlaying(v) && !v.muted && v.volume > 0 && area(v) > 0);

  function showFound(item) {
    if (!findVideos().length) return false;
    if (!found.some((f) => f.id === item.id) && !waiting.some((w) => w.item.id === item.id)) waiting.push({ item, t: Date.now() });
    flushFound();
    return true;
  }

  function flushFound() {
    if (!waiting.length) return;
    const v = watched();
    if (!v) return;
    const fresh = waiting.splice(0).filter((w) => Date.now() - w.t < WAIT_MS);
    if (!fresh.length) return;
    if (!video) attach(v);
    ensureHost();
    for (const w of fresh) if (!found.some((f) => f.id === w.item.id)) found.unshift(w.item);
    found.length = Math.min(found.length, 3);
    renderFound();
    position(true);
  }

  // Media events don't bubble, so listen in the capture phase.
  document.addEventListener('playing', flushFound, true);
  document.addEventListener('volumechange', flushFound, true);

  function renderFound(message) {
    const head = el('div', 'found-head');
    head.append(el('span', '', found.length > 1 ? 'Subtitles found on this page' : 'Subtitles found'));
    const close = el('button', 'x', '×');
    close.title = 'Close';
    close.addEventListener('click', hideFound);
    head.append(close);
    const rows = found.map((item) => {
      const row = el('div', 'found-row');
      if (item.lang) row.append(el('span', 'found-lang', item.lang));
      const name = el('span', 'found-name', item.name);
      name.title = item.name;
      const dl = el('button', 'main', 'Download .srt');
      dl.addEventListener('click', () => foundAction(dl, 'Download .srt', { type: 'convert-item', id: item.id, format: 'srt' },
        (res) => {
          SubLib.saveText(res.text, res.filename);
          return { text: 'Saved to Downloads (' + res.count + ' lines)', translate: true, saved: true };
        }));
      const use = el('button', '', 'Show over video');
      use.addEventListener('click', () => foundAction(use, 'Show over video', { type: 'fetch-item', id: item.id }, (res) => {
        const r = loadBytes(res.name, res.b64, 'auto', video || pickVideo());
        if (!r.ok) throw new Error(r.error);
        return 'Showing ' + r.count + ' lines. Turn the site’s own subtitles off.';
      }));
      row.append(name, dl, use);
      return row;
    });
    foundEl.replaceChildren(head, ...rows);
    if (message) {
      const line = el('div', 'found-msg');
      line.append(el('span', message.saved ? 'saved' : '', message.text || message));
      if (message.translate) {
        const tr = el('button', '', 'Translate \u2197');
        tr.title = 'Opens translate-subtitles.com. Upload the downloaded file there.';
        tr.addEventListener('click', () => send({ type: 'open-translator' }));
        line.append(tr);
      }
      foundEl.append(line);
    }
    foundEl.classList.add('on');
    clearTimeout(foundTimer);
    foundTimer = setTimeout(hideFound, message ? 12000 : 20000);
  }

  async function foundAction(button, label, msg, done) {
    button.disabled = true;
    button.textContent = '…';
    let message;
    try {
      const res = await chrome.runtime.sendMessage(msg);
      if (!res || !res.ok) throw new Error(res ? res.error : 'Failed.');
      message = done(res);
    } catch (e) {
      message = 'Didn’t work: ' + e.message;
    }
    renderFound(message);
  }

  function hideFound() {
    clearTimeout(foundTimer);
    if (foundEl) foundEl.classList.remove('on');
    found.length = 0;
  }

  // ---------- popup / background messages ----------

  function videoList() {
    const current = video && cues.length ? video : pickVideo();
    return findVideos().map((v, index) => {
      const r = v.getBoundingClientRect();
      const tracks = [...v.textTracks].map((t, ti) => ({
        index: ti, label: t.label, language: t.language, kind: t.kind,
        count: t.cues ? t.cues.length : 0,
        preview: t.cues && t.cues.length ? String(t.cues[0].text || '').split('\n')[0] : '',
      })).filter((t) => t.count > 0);
      return {
        index, width: Math.round(r.width), height: Math.round(r.height), visible: area(v) > 0,
        playing: isPlaying(v), current: v === current, tracks,
      };
    }).filter((x) => x.visible || x.tracks.length);
  }

  function report() {
    return {
      url: location.href,
      host: location.hostname,
      top: window === window.top,
      videos: videoList(),
      loaded: cues.length ? { name: file.name, count: cues.length, encoding: file.encoding, usedEncoding: file.usedEncoding } : null,
    };
  }

  // Cues from the video's own text tracks (method 1 of capture), as WebVTT text.
  function trackAsVtt(videoIndex, trackIndex) {
    const v = findVideos()[videoIndex];
    const t = v && v.textTracks[trackIndex];
    if (!t || !t.cues) return null;
    const list = [...t.cues].map((c) => ({ start: Math.round(c.startTime * 1000), end: Math.round(c.endTime * 1000), text: c.text || '' }));
    return SubLib.toVTT(list);
  }

  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    switch (msg.type) {
      case 'load': {
        const v = msg.videoIndex != null ? findVideos()[msg.videoIndex] : null;
        if (v) pinned = v;
        reply(loadBytes(msg.name, msg.b64, msg.encoding, v));
        return;
      }
      case 'set-encoding': {
        if (!file) return reply({ ok: false, error: 'Nothing loaded.' });
        reply(loadBytes(file.name, file.b64, msg.encoding, video));
        return;
      }
      case 'use-font':
        // The popup waits for this to say "on the video".
        SubRender.ensureFont(document, msg.font)
          .then(() => { position(true); reply({ ok: true }); }, (e) => reply({ ok: false, error: e.message }));
        return true;
      case 'clear':
        clearSubs();
        try { chrome.storage.session.remove(pageKey()); } catch (e) { /* ignore */ }
        reply({ ok: true });
        return;
      case 'export':
        reply(file ? { name: file.name, b64: file.b64, encoding: file.encoding } : null);
        return;
      case 'select-video': {
        const v = findVideos()[msg.index];
        if (!v) return reply({ ok: false });
        pinned = v;
        if (cues.length) attach(v);
        reply({ ok: true });
        return;
      }
      case 'track-vtt':
        reply({ text: trackAsVtt(msg.videoIndex, msg.trackIndex) });
        return;
      case 'run-action':
        if (cues.length) runAction(msg.action);
        return;
      case 'subs-found':
        reply({ shown: showFound(msg.item) });
        return;
      case 'tab-subs':
        tabHasSubs = msg.has;
        return;
      case 'fetch-url':
        // Fallback download from inside the page, with the page's own cookies.
        fetch(msg.url, { credentials: 'include' })
          .then((r) => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.arrayBuffer(); })
          .then((buf) => reply({ ok: true, b64: SubLib.bytesToBase64(new Uint8Array(buf)) }))
          .catch((e) => reply({ ok: false, error: String(e.message || e) }));
        return true;
    }
  });

  window.__subOverlay = { report };
  checkSessionRestore();
})();
