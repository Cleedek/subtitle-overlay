// Popup: loads files, lists found subtitles, edits settings (applied live).
(async function () {
  'use strict';
  const { SubLib, SubSettings, SubRender } = globalThis;
  const $ = (id) => document.getElementById(id);

  const style = document.createElement('style');
  style.textContent = SubRender.CSS;
  document.head.appendChild(style);

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let frames = [];      // [{ frameId, report }]
  let settings = await SubSettings.load();

  // ---------- page state ----------

  async function scan() {
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id, allFrames: true },
        func: () => (window.__subOverlay ? window.__subOverlay.report() : null),
      });
      frames = results.filter((r) => r.result).map((r) => ({ frameId: r.frameId, report: r.result }));
    } catch (e) {
      frames = null;
    }
    renderPage();
  }

  const allVideos = () => (frames || []).flatMap((f) => f.report.videos.map((v) => Object.assign({ frameId: f.frameId, host: f.report.host }, v)));
  const loadedFrame = () => (frames || []).find((f) => f.report.loaded);

  // The video subtitles go to: the one showing them now, else the content
  // script's own pick in the top-most frame that has one, else the largest.
  function targetVideo() {
    const vids = allVideos();
    const chosen = $('videoSelect').value;
    if (chosen) {
      const [frameId, index] = chosen.split(':').map(Number);
      const v = vids.find((x) => x.frameId === frameId && x.index === index);
      if (v) return v;
    }
    const lf = loadedFrame();
    const current = vids.filter((v) => v.current && v.visible);
    if (lf) return current.find((v) => v.frameId === lf.frameId) || current[0];
    const playing = current.filter((v) => v.playing);
    const pool = playing.length ? playing : current.length ? current : vids.filter((v) => v.visible);
    return pool.sort((a, b) => b.width * b.height - a.width * a.height)[0];
  }

  function renderPage() {
    if (frames === null) {
      $('status').textContent = 'This page can’t be used (browser pages, the Web Store and PDFs are off limits).';
      for (const id of ['pick', 'clear']) $(id).disabled = true;
      $('captured').replaceChildren();
      return;
    }
    const vids = allVideos().filter((v) => v.visible);
    const lf = loadedFrame();
    const anyPlaying = vids.some((v) => v.playing);
    $('status').textContent = vids.length
      ? vids.length + (vids.length === 1 ? ' video' : ' videos') + ' on this page' + (anyPlaying ? ', playing' : '')
      : 'No video found yet. Start playing one, then reopen this.';

    $('loaded').hidden = !lf;
    $('clear').hidden = !lf;
    $('pick').textContent = lf ? 'Load a different file' : 'Load .srt / .vtt file';
    $('pick').classList.toggle('primary', !lf); // with a file loaded, Translate is the main action
    if (lf) {
      const l = lf.report.loaded;
      $('loadedName').textContent = l.name;
      $('loadedCount').textContent = '· ' + l.count + ' lines';
      $('encoding').value = l.encoding;
      const auto = $('encoding').querySelector('option[value=auto]');
      auto.textContent = 'Auto' + (l.encoding === 'auto' ? ' (' + l.usedEncoding + ')' : '');
      renderTranslate(l);
      const r = lf.report;
      $('siteHidden').hidden = !(r.siteHidden && r.siteHidden.length) && !r.siteVisible;
      $('siteHidden').classList.toggle('warn', !!r.siteVisible);
      $('siteHidden').textContent = r.siteVisible
        ? 'The site\u2019s own subtitles are still showing. Turn them off in its player.'
        : 'Site\u2019s own subtitles hidden: ' + (r.siteHidden || []).join(', ');
    }

    // Video picker only when there is a real choice.
    $('videoPicker').hidden = vids.length < 2;
    if (vids.length > 1) {
      const t = targetVideo();
      $('videoSelect').replaceChildren(...vids.map((v, i) => {
        const o = document.createElement('option');
        o.value = v.frameId + ':' + v.index;
        o.textContent = 'Video ' + (i + 1) + ' · ' + v.width + '×' + v.height + (v.playing ? ' · playing' : '') + (v.frameId ? ' · ' + v.host : '');
        return o;
      }));
      if (t) $('videoSelect').value = t.frameId + ':' + t.index;
    }

    $('preview').hidden = anyPlaying;
    renderPreview();
    renderCaptured();
  }

  // ---------- loading into the page ----------

  async function loadIntoPage(name, b64) {
    const target = targetVideo();
    if (!target) return { ok: false, error: 'No video found on this page.' };
    const lf = loadedFrame();
    if (lf && lf.frameId !== target.frameId) {
      await chrome.tabs.sendMessage(tab.id, { type: 'clear' }, { frameId: lf.frameId }).catch(() => {});
    }
    const res = await chrome.tabs.sendMessage(tab.id, { type: 'load', name, b64, encoding: 'auto', videoIndex: target.index }, { frameId: target.frameId })
      .catch((e) => ({ ok: false, error: 'The page didn’t answer. Reload the page and try again.' }));
    await scan();
    return res;
  }

  $('pick').addEventListener('click', () => $('file').click());
  $('file').addEventListener('change', async () => {
    const f = $('file').files[0];
    if (!f) return;
    const bytes = new Uint8Array(await f.arrayBuffer());
    const res = await loadIntoPage(f.name, SubLib.bytesToBase64(bytes));
    if (!res.ok) $('status').textContent = res.error;
    $('file').value = '';
  });

  $('clear').addEventListener('click', async () => {
    const lf = loadedFrame();
    if (lf) await chrome.tabs.sendMessage(tab.id, { type: 'clear' }, { frameId: lf.frameId }).catch(() => {});
    scan();
  });

  $('encoding').addEventListener('change', async () => {
    const lf = loadedFrame();
    if (!lf) return;
    await chrome.tabs.sendMessage(tab.id, { type: 'set-encoding', encoding: $('encoding').value }, { frameId: lf.frameId }).catch(() => {});
    scan();
  });

  $('videoSelect').addEventListener('change', async () => {
    const t = targetVideo();
    const lf = loadedFrame();
    if (!t) return;
    if (lf && lf.frameId !== t.frameId) {
      // Move the loaded file to a video in another frame.
      const file = await chrome.tabs.sendMessage(tab.id, { type: 'export' }, { frameId: lf.frameId }).catch(() => null);
      if (file) await loadIntoPage(file.name, file.b64);
    } else {
      await chrome.tabs.sendMessage(tab.id, { type: 'select-video', index: t.index }, { frameId: t.frameId }).catch(() => {});
      scan();
    }
  });

  // ---------- translation ----------

  // The language picker sits right next to the button; whatever you pick is
  // remembered as your favourite and used by every Translate button.
  const prefs = await SubSettings.loadTranslation();
  let lang = prefs.translateTo;
  for (const key of ['autoTranslate']) {
    $(key).checked = prefs[key];
    $(key).addEventListener('change', () => SubSettings.saveTranslation({ [key]: $(key).checked }));
  }
  $('lang').replaceChildren(...SubSettings.LANGUAGES.map(([code, name]) => {
    const o = document.createElement('option');
    o.value = code;
    o.textContent = name;
    return o;
  }));
  $('lang').value = lang;

  function renderTranslate(l) {
    const showing = l.translatedTo;
    $('translatedRow').hidden = !showing;
    $('translatedLang').textContent = showing ? SubSettings.languageName(showing) : '';
    // Already showing the picked language: nothing to translate.
    $('translateBtn').hidden = showing === lang;
    $('translateBtn').textContent = 'Translate to ' + SubSettings.languageName(lang);
  }

  function translateMsg(text) {
    $('translateMsg').hidden = !text;
    $('translateMsg').textContent = text || '';
  }

  // Asks the frame with the subtitles to translate them (the background does the Google request).
  async function translateLoaded(frameId) {
    const res = await chrome.tabs.sendMessage(tab.id, { type: 'translate', to: lang }, { frameId })
      .catch(() => ({ ok: false, error: 'The page didn\u2019t answer. Reload the page and try again.' }));
    await scan();
    return res;
  }

  $('lang').addEventListener('change', async () => {
    lang = $('lang').value;
    await SubSettings.saveTranslation({ translateTo: lang });
    translateMsg('');
    const lf = loadedFrame();
    if (lf) renderTranslate(lf.report.loaded);
    renderCaptured();
    renderLangChip();
    if (googleFonts.length) renderFonts();
    renderPreview(true);
  });

  $('translateBtn').addEventListener('click', async () => {
    const lf = loadedFrame();
    if (!lf) return;
    const b = $('translateBtn');
    b.disabled = true;
    b.textContent = 'Translating\u2026';
    translateMsg('');
    const res = await translateLoaded(lf.frameId);
    b.disabled = false;
    const lf2 = loadedFrame();
    if (lf2) renderTranslate(lf2.report.loaded);
    if (!res || !res.ok) translateMsg(res ? res.error : 'Translation failed.');
  });

  $('showOriginal').addEventListener('click', async () => {
    const lf = loadedFrame();
    if (lf) await chrome.tabs.sendMessage(tab.id, { type: 'show-original' }, { frameId: lf.frameId }).catch(() => {});
    scan();
  });

  $('downloadTranslated').addEventListener('click', async () => {
    const lf = loadedFrame();
    const file = lf && await chrome.tabs.sendMessage(tab.id, { type: 'export' }, { frameId: lf.frameId }).catch(() => null);
    if (file) await download(file, 'srt').catch((e) => translateMsg(e.message));
  });

  // ---------- found subtitles ----------

  let capturedItems = [];
  const details = new Map(); // id -> details or { error }

  async function refreshCaptured() {
    capturedItems = await chrome.runtime.sendMessage({ type: 'get-captured', tabId: tab.id }).catch(() => []) || [];
    renderCaptured();
    for (const item of capturedItems) {
      if (details.has(item.id)) continue;
      details.set(item.id, item.details || null);
      if (item.details) continue;
      chrome.runtime.sendMessage({ type: 'item-details', tabId: tab.id, id: item.id }).then((res) => {
        details.set(item.id, res && res.ok ? res.details : { error: res ? res.error : 'Failed.' });
        if (res && res.lang) item.lang = res.lang;
        renderCaptured();
      });
    }
  }

  // Episode name from the page (top frame first), shown as the card title;
  // the file name moves into the line under it.
  function episodeTitle() {
    const top = (frames || []).find((f) => f.frameId === 0);
    return (top && top.report.title) || ((frames || []).find((f) => f.report.title) || { report: {} }).report.title || '';
  }

  function renderCaptured() {
    const box = $('captured');
    const cards = [];
    const episode = episodeTitle();
    for (const item of capturedItems) {
      const d = details.get(item.id);
      const file = item.name || decodeURIComponent(item.url.split(/[?#]/)[0].split('/').pop() || item.url);
      let meta;
      if (!d) meta = 'Checking…';
      else if (d.error) meta = d.error;
      else if (item.kind === 'hls') meta = 'Streaming subtitles' + (d.count ? ' · ' + d.count + ' lines' : d.pieces ? ' · ' + d.pieces + ' pieces' : '') + (d.preview ? ' · "' + d.preview + '"' : '');
      else meta = d.count + ' lines' + (d.preview ? ' · "' + d.preview + '"' : '');
      if (episode) meta = file + ' · ' + meta;
      cards.push(card(item.lang, episode || file, meta, item.url, () => fetchNetworkItem(item)));
    }
    for (const v of allVideos()) {
      for (const t of v.tracks) {
        const meta = t.count + ' lines' + (t.preview ? ' · "' + t.preview + '"' : '') + ' · from the player';
        cards.push(card(t.language, t.label || 'Player track ' + (t.index + 1), meta, '', async () => {
          const res = await chrome.tabs.sendMessage(tab.id, { type: 'track-vtt', videoIndex: v.index, trackIndex: t.index }, { frameId: v.frameId }).catch(() => null);
          if (!res || !res.text) return { ok: false, error: 'The track has no lines yet.' };
          return { ok: true, name: (t.label || t.language || 'track') + '.vtt', b64: SubLib.bytesToBase64(new TextEncoder().encode(res.text)) };
        }));
      }
    }
    if (!cards.length) {
      const p = document.createElement('div');
      p.className = 'empty';
      p.textContent = 'No subtitle files seen yet. Turn on subtitles in the site’s own player (for example the CC button on Prima+), let it play a moment, then open this again.';
      cards.push(p);
    }
    box.replaceChildren(...cards);
  }

  function fetchNetworkItem(item) {
    return chrome.runtime.sendMessage({ type: 'fetch-item', tabId: tab.id, id: item.id })
      .catch((e) => ({ ok: false, error: e.message }));
  }

  // One found file: language, title, line count + preview, and three actions.
  function card(lang, title, meta, url, getFile) {
    const c = document.createElement('div');
    c.className = 'item';
    const head = document.createElement('div');
    head.className = 'item-head';
    if (lang) {
      const b = document.createElement('span');
      b.className = 'badge';
      b.textContent = lang;
      head.append(b);
    }
    const t = document.createElement('span');
    t.className = 'item-title';
    t.textContent = title;
    if (url) t.title = url;
    head.append(t);
    const m = document.createElement('div');
    m.className = 'item-meta';
    m.textContent = meta;
    m.title = meta;
    const row = document.createElement('div');
    row.className = 'row';
    const err = document.createElement('div');
    err.className = 'error';

    const run = (label, fn) => {
      const b = document.createElement('button');
      b.textContent = label;
      b.addEventListener('click', async () => {
        err.textContent = '';
        b.disabled = true;
        const old = b.textContent;
        b.textContent = '…';
        try {
          const file = await getFile();
          if (!file || !file.ok) throw new Error(file ? file.error : 'Failed.');
          await fn(file);
        } catch (e) {
          err.textContent = e.message;
        }
        b.disabled = false;
        b.textContent = old;
      });
      return b;
    };

    row.append(
      run('Use as overlay', async (file) => {
        const res = await loadIntoPage(file.name, file.b64);
        if (!res.ok) throw new Error(res.error);
      }),
      run('Download .vtt', async (file) => { await download(file, 'vtt'); c.append(translateNote()); }),
      run('Download .srt', async (file) => { await download(file, 'srt'); c.append(translateNote()); }),
      run('Translate to ' + SubSettings.languageName(lang), async (file) => {
        const res = await loadIntoPage(file.name, file.b64);
        if (!res.ok) throw new Error(res.error);
        const lf = loadedFrame();
        const t = lf ? await translateLoaded(lf.frameId) : { ok: false, error: 'The subtitles didn\u2019t reach the video.' };
        if (!t || !t.ok) throw new Error(t ? t.error : 'Translation failed.');
      }),
    );
    c.append(head, m, row, err);
    return c;
  }

  // After a download: "Saved to Downloads. Translate it ↗"
  function translateNote() {
    document.querySelectorAll('.translate').forEach((n) => n.remove());
    const p = document.createElement('div');
    p.className = 'translate';
    const done = document.createElement('div');
    done.className = 'saved';
    done.textContent = 'Saved to Downloads';
    const a = document.createElement('a');
    a.href = '#';
    a.textContent = 'Translate it on translate-subtitles.com\u00a0↗';
    a.addEventListener('click', (e) => { e.preventDefault(); chrome.runtime.sendMessage({ type: 'open-translator' }); });
    p.append(done, a);
    return p;
  }

  async function download(file, format) {
    const { text } = SubLib.decode(SubLib.base64ToBytes(file.b64), 'auto');
    const cues = SubLib.parse(text);
    if (!cues.length) throw new Error('No subtitle lines found.');
    const out = format === 'srt' ? SubLib.toSRT(cues) : SubLib.toVTT(cues);
    const base = file.name.replace(/\.(web)?vtt$|\.srt$/i, '');
    SubLib.saveText(out, base + '.' + format);
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'captured-changed' && msg.tabId === tab.id) refreshCaptured();
  });

  // ---------- settings ----------

  const controls = [...document.querySelectorAll('[data-key]')];

  function showSettings() {
    for (const c of controls) {
      const v = settings[c.dataset.key];
      if (c.type === 'checkbox') c.checked = !!v;
      else c.value = v;
    }
    for (const r of document.querySelectorAll('input[type=range]')) paintRange(r);
    for (const o of document.querySelectorAll('output[data-for]')) {
      o.textContent = settings[o.dataset.for] + (o.dataset.unit || ' px');
    }
    $('offset').value = settings.offset;
    renderPreview();
    renderPresets();
    if (googleFonts.length) renderFonts();
    SubRender.ensureFont(document, settings.font).then(renderPreview, () => {});
  }

  // The filled part of a slider's track, up to the thumb.
  function paintRange(r) {
    const min = Number(r.min) || 0, max = Number(r.max) || 100;
    r.style.setProperty('--fill', ((Number(r.value) - min) / (max - min)) * 100 + '%');
  }

  // Save at most once per frame while a slider is being dragged.
  let pending = {}, queued = false;
  function queueSave(patch) {
    Object.assign(pending, patch);
    Object.assign(settings, patch);
    showSettings();
    if (queued) return;
    queued = true;
    requestAnimationFrame(async () => {
      queued = false;
      const p = pending;
      pending = {};
      settings = await SubSettings.save(p);
      showSettings();
    });
  }

  for (const c of controls) {
    c.addEventListener('input', () => {
      const key = c.dataset.key;
      let value = c.type === 'checkbox' ? c.checked : c.value;
      if (c.type === 'range' || c.type === 'number' || key === 'weight') value = Number(value);
      if (c.type === 'number' && c.value === '') return;
      queueSave({ [key]: c.type === 'number' || c.type === 'range' ? SubSettings.clamp(key, value) : value });
    });
  }

  for (const b of document.querySelectorAll('[data-offset]')) {
    b.addEventListener('click', () => queueSave({ offset: SubSettings.clamp('offset', settings.offset + Number(b.dataset.offset)) }));
  }
  $('offset').addEventListener('change', () => queueSave({ offset: SubSettings.clamp('offset', $('offset').value) }));
  $('offsetReset').addEventListener('click', () => queueSave({ offset: 0 }));

  $('resetAll').addEventListener('click', async () => {
    settings = await SubSettings.reset();
    showSettings();
  });

  // ---------- presets ----------

  let userPresets = await SubSettings.loadPresets();
  const builtIn = [...document.querySelectorAll('[data-preset]')];
  for (const b of builtIn) b.addEventListener('click', () => queueSave(SubSettings.PRESETS[b.dataset.preset]));

  const matches = (values) => Object.keys(values).every((k) => settings[k] === values[k]);

  function renderPresets() {
    const box = $('presets');
    box.querySelectorAll('.user').forEach((n) => n.remove());
    for (const b of builtIn) b.classList.toggle('on', matches(SubSettings.PRESETS[b.dataset.preset]));
    for (const p of userPresets) {
      const b = document.createElement('button');
      b.className = 'user' + (matches(p.values) ? ' on' : '');
      const name = document.createElement('span');
      name.textContent = p.name;
      const del = document.createElement('i');
      del.textContent = '×';
      del.title = 'Delete preset "' + p.name + '"';
      del.addEventListener('click', async (e) => {
        e.stopPropagation();
        userPresets = await SubSettings.deletePreset(p.name);
        renderPresets();
      });
      b.append(name, del);
      b.addEventListener('click', () => queueSave(Object.assign({}, p.values)));
      box.append(b);
    }
  }

  function toggleSaveForm(open) {
    $('saveForm').hidden = !open;
    $('presetNew').hidden = open;
    if (open) {
      $('presetName').value = 'My preset ' + (userPresets.length + 1);
      $('presetName').select();
    }
  }
  async function savePreset() {
    const name = $('presetName').value.trim();
    if (!name) return $('presetName').focus();
    userPresets = await SubSettings.savePreset(name, settings);
    toggleSaveForm(false);
    renderPresets();
    $('presets').scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
  $('presetNew').addEventListener('click', () => toggleSaveForm(true));
  $('presetCancel').addEventListener('click', () => toggleSaveForm(false));
  $('presetSave').addEventListener('click', savePreset);
  $('presetName').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') savePreset();
    if (e.key === 'Escape') { e.preventDefault(); toggleSaveForm(false); }
  });

  // ---------- font picker ----------

  const SYSTEM_FONTS = [['sans', 'System sans'], ['serif', 'Serif'], ['mono', 'Monospace']];
  const CATEGORY = { s: 'Sans', r: 'Serif', d: 'Display', h: 'Handwriting', m: 'Mono' };
  let googleFonts = [];
  fetch('lib/google-fonts.json').then((r) => r.json()).then((list) => { googleFonts = list; renderFonts(); });
  const fontFilter = { cat: '', cs: true, lang: true };
  // The second letter chip follows the language you translate into.
  const langNeed = () => SubSettings.language(lang)[2];
  const hasAlphabet = (f, need) => !need || (f[5] || '').includes(need);
  function renderLangChip() {
    const [, name, need, sample] = SubSettings.language(lang);
    // Plain latin (Italian, German...) fits every font; Czech has its own chip already.
    $('needLang').hidden = !need || lang === 'cs';
    $('needLang').textContent = sample;
    $('needLang').title = 'Only fonts that have ' + name + ' letters (your translation language)';
    $('needLang').classList.toggle('on', fontFilter.lang);
  }

  function renderFonts() {
    const q = $('fontSearch').value.trim().toLowerCase();
    const rows = [];
    const row = (value, label, tags) => {
      const b = document.createElement('button');
      b.className = 'font-row' + (settings.font === value ? ' on' : '');
      b.setAttribute('role', 'option');
      const n = document.createElement('span');
      n.className = 'name';
      n.textContent = label;
      b.append(n);
      for (const t of tags) {
        const s = document.createElement('span');
        s.className = 'tag';
        s.textContent = t;
        b.append(s);
      }
      b.addEventListener('click', () => pickFont(value));
      rows.push(b);
    };
    if (!q && !fontFilter.cat) for (const [v, l] of SYSTEM_FONTS) row(v, l, ['built in']);
    const hits = googleFonts.filter((f) => (!q || f[0].toLowerCase().includes(q))
      && (!fontFilter.cat || f[1] === fontFilter.cat) && (!fontFilter.cs || f[3])
      && ($('needLang').hidden || !fontFilter.lang || hasAlphabet(f, langNeed())));
    // The current font stays visible at the top even when the filters hide it.
    const current = SubRender.isGoogle(settings.font) && googleFonts.find((f) => f[0] === SubRender.googleName(settings.font));
    const shown = hits.slice(0, 60);
    if (current && !shown.includes(current) && !q) shown.unshift(current);
    const code = lang.split('-')[0].toUpperCase();
    for (const f of shown) {
      row('g:' + f[0], f[0], [CATEGORY[f[1]]].concat(f[3] ? ['CZ'] : [], langNeed() && lang !== 'cs' && hasAlphabet(f, langNeed()) ? [code] : []));
    }
    if (hits.length > shown.length) {
      const more = document.createElement('div');
      more.className = 'more';
      more.textContent = (hits.length - 60) + ' more, type to search';
      rows.push(more);
    }
    if (!rows.length) {
      const none = document.createElement('div');
      none.className = 'more';
      none.textContent = 'No font matches.';
      rows.push(none);
    }
    $('fontList').replaceChildren(...rows);
  }

  // Downloads the font right away and asks the page to switch to it, so you see
  // whether it really reached the video (an old copy of the page script, left
  // over after the extension was updated, never answers).
  async function pickFont(value) {
    queueSave({ font: value });
    const status = $('fontStatus');
    const say = (text, kind) => {
      if (settings.font !== value) return; // another font was picked meanwhile
      status.hidden = false;
      status.className = 'font-status' + (kind ? ' ' + kind : '');
      status.textContent = text;
    };
    if (!SubRender.isGoogle(value)) { status.hidden = true; return; }
    const name = SubRender.googleName(value);
    say('Downloading ' + name + '…');
    try {
      await SubRender.ensureFont(document, value);
      renderPreview();
      const lf = loadedFrame();
      if (!lf) return say(name + ' is ready. It is used as soon as subtitles are on.', 'ok');
      const res = await chrome.tabs.sendMessage(tab.id, { type: 'use-font', font: value }, { frameId: lf.frameId }).catch(() => null);
      if (res && res.ok) say(name + ' is on the video.', 'ok');
      else if (res) throw new Error(res.error);
      else say('The page didn\'t answer. Reload the page (needed after the extension is updated), your subtitles come back on their own.', 'error');
    } catch (e) {
      say('Couldn\'t load ' + name + ': ' + e.message, 'error');
    }
  }

  $('fontSearch').addEventListener('input', renderFonts);
  for (const b of document.querySelectorAll('[data-cat]')) {
    b.addEventListener('click', () => {
      fontFilter.cat = b.dataset.cat;
      document.querySelectorAll('[data-cat]').forEach((x) => x.classList.toggle('on', x === b));
      renderFonts();
    });
  }
  for (const [id, key] of [['needCs', 'cs'], ['needLang', 'lang']]) {
    $(id).addEventListener('click', () => {
      fontFilter[key] = !fontFilter[key];
      $(id).classList.toggle('on', fontFilter[key]);
      renderFonts();
    });
  }
  renderLangChip();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.settings || queued) return;
    settings = Object.assign({}, SubSettings.DEFAULTS, changes.settings.newValue);
    showSettings();
  });

  function renderPreview(fresh) {
    if ($('preview').hidden) return;
    const el = $('previewSubs');
    if (fresh) el.replaceChildren();
    // The preview pretends to be a 540 px tall player, so scaled text is readable.
    SubRender.applyStyle(el, settings, 540, $('preview').clientWidth || 352);
    const [, name, , sample] = SubSettings.language(lang);
    if (!el.childNodes.length) SubRender.renderCues(el, [{ text: 'Příliš žluťoučký kůň <i>úpěl</i>' + (lang === 'cs' ? '' : '\n' + name + ' ' + sample) }]);
  }

  // Mac keyboards say Option and Shift with symbols; draw the keys the same way.
  if (/Mac/i.test(navigator.platform)) {
    document.querySelectorAll('kbd[data-mod=alt]').forEach((k) => { k.textContent = '\u2325'; k.title = 'Option'; });
    document.querySelectorAll('kbd[data-mod=shift]').forEach((k) => { k.textContent = '\u21e7'; k.title = 'Shift'; });
    $('keysNote').textContent = '\u2325 is Option, \u21e7 is Shift. Shortcuts work on the page, not inside this popup.';
  }

  showSettings();
  await scan();
  refreshCaptured();
})();
