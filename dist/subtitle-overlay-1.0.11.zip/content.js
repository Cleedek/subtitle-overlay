// Runs in every page and frame. Finds the video, draws the subtitle layer on
// top of it and keeps it in sync with the video's own clock.
(function () {
  'use strict';
  if (window.__subOverlay) return;

  const { SubLib, SubSettings, SubRender } = globalThis;

  let settings = Object.assign({}, SubSettings.DEFAULTS);
  let cues = [];          // loaded subtitle lines, sorted by start (ms)
  let file = null;        // { name, b64, encoding, usedEncoding } of the loaded file
  let stashed = null;     // previous subtitles after a video swap, for "Restore"
  let original = null;    // { file, cues } of the untranslated subtitles while a translation shows
  const translations = new Map(); // language -> translated cues, so switching back is instant
  let prefs = Object.assign({}, SubSettings.TRANSLATION); // language, automatic mode, hide the site's subtitles
  let autoLoaded = false; // the subtitles on screen came from automatic mode (a newer file may replace them)
  let video = null;       // the video the overlay follows
  let pinned = null;      // video chosen by hand in the popup
  let visible = true;     // Alt + S
  let tabHasSubs = false; // some frame in this tab has subtitles (for shortcut forwarding)
  let lastSrc = '';
  let lastAdAt = 0;
  let lastKey = '';
  let lastGeom = '';
  let raf = 0;
  let watchTimer = 0;
  let bareFullscreen = false;
  let ownFullscreen = null; // { container, videoStyle } while our own fullscreen is on

  // ---------- storage ----------

  SubSettings.load().then((s) => { settings = s; refreshStyle(); });
  SubSettings.loadTranslation().then((p) => { prefs = p; });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') {
      for (const k of Object.keys(SubSettings.TRANSLATION)) {
        if (changes[k]) prefs[k] = changes[k].newValue != null ? changes[k].newValue : SubSettings.TRANSLATION[k];
      }
    }
    if (area !== 'local' || !changes.settings) return;
    settings = Object.assign({}, SubSettings.DEFAULTS, changes.settings.newValue || {});
    refreshStyle();
  });

  const pageKey = () => 'page:' + location.href;

  async function rememberFile() {
    try {
      await chrome.storage.session.set({ [pageKey()]: Object.assign({ t: Date.now() }, file) });
      // Keep only the 20 most recent pages so session storage stays small.
      const all = await chrome.storage.session.get(null);
      const pages = Object.keys(all).filter((k) => k.startsWith('page:')).sort((a, b) => all[b].t - all[a].t);
      if (pages.length > 20) await chrome.storage.session.remove(pages.slice(20));
    } catch (e) { /* session storage unavailable; reload just won't restore */ }
  }

  function send(msg) {
    try { return chrome.runtime.sendMessage(msg).catch(() => {}); } catch (e) { return Promise.resolve(); }
  }

  // ---------- finding videos ----------

  // All <video> elements in this frame, including inside open shadow roots.
  function findVideos() {
    const found = [...document.querySelectorAll('video')];
    const walk = (rootNode) => {
      const all = rootNode.querySelectorAll('*');
      for (const el of all) {
        if (!el.shadowRoot) continue;
        found.push(...el.shadowRoot.querySelectorAll('video'));
        walk(el.shadowRoot);
      }
    };
    walk(document);
    return [...new Set(found)];
  }

  function area(v) {
    const r = v.getBoundingClientRect();
    if (r.width < 50 || r.height < 50) return 0;
    const st = getComputedStyle(v);
    if (st.visibility === 'hidden' || st.display === 'none' || +st.opacity === 0) return 0;
    return r.width * r.height;
  }

  const isPlaying = (v) => !v.paused && !v.ended && v.readyState > 2;

  // Pinned video first, then the largest playing one, then the largest visible one.
  function pickVideo() {
    if (pinned && pinned.isConnected) return pinned;
    const vids = findVideos().map((v) => ({ v, a: area(v) })).filter((x) => x.a > 0);
    if (!vids.length) return null;
    const playing = vids.filter((x) => isPlaying(x.v));
    const pool = playing.length ? playing : vids;
    pool.sort((a, b) => b.a - a.a);
    return pool[0].v;
  }

  // ---------- overlay DOM ----------

  let host, shadow, subsEl, toastEl, hintEl, fsBtn, dropEl, foundEl, siteNoteEl;

  function ensureHost() {
    if (host) return;
    host = document.createElement('subtitle-overlay-root');
    const hs = host.style;
    for (const [k, v] of Object.entries({
      all: 'initial', position: 'fixed', left: '0px', top: '0px', width: '0px', height: '0px',
      'z-index': '2147483647', 'pointer-events': 'none', display: 'block', overflow: 'visible',
      contain: 'layout style',
    })) hs.setProperty(k, v, 'important');
    shadow = host.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = SubRender.CSS + `
      :host { all: initial; }
      .toast, .hint, .fs, .drop { font: 600 14px/1.3 system-ui, -apple-system, "Segoe UI", sans-serif; color: #fff; }
      .toast {
        position: absolute; top: max(10%, 52px); left: 50%; transform: translateX(-50%);
        background: rgba(20,20,20,.85); padding: 6px 12px; border-radius: 999px;
        opacity: 0; transition: opacity .2s; white-space: nowrap; pointer-events: none;
      }
      .toast.on { opacity: 1; }
      .hint {
        position: absolute; top: 12px; left: 50%; transform: translateX(-50%);
        display: none; align-items: center; gap: 8px; pointer-events: auto;
        background: rgba(20,20,20,.9); padding: 6px 6px 6px 12px; border-radius: 10px; white-space: nowrap;
      }
      .hint.on { display: flex; }
      .site-note {
        position: absolute; top: 12px; left: 12px; max-width: min(360px, calc(100% - 24px));
        display: none; align-items: center; gap: 10px; pointer-events: auto;
        background: rgba(20,20,20,.92); padding: 8px 6px 8px 12px; border-radius: 10px;
        font: 500 13px/1.35 system-ui, -apple-system, "Segoe UI", sans-serif; color: #fff;
      }
      .site-note.on { display: flex; }
      .site-note b { font-weight: 700; }
      .site-note button { font: inherit; color: #fff; background: transparent; border: 0; border-radius: 7px; padding: 2px 8px; cursor: pointer; }
      .site-note button:hover { background: rgba(255,255,255,.18); }
      .hint button, .fs {
        font: inherit; color: #fff; background: rgba(255,255,255,.16); border: 0;
        border-radius: 7px; padding: 4px 10px; cursor: pointer;
      }
      .hint button:hover, .fs:hover { background: rgba(255,255,255,.28); }
      /* Top centre: players rarely put their own controls there. */
      .fs {
        position: absolute; top: 12px; left: 50%; transform: translateX(-50%); display: none; pointer-events: auto;
        background: rgba(20,20,20,.75); font-size: 13px; white-space: nowrap;
      }
      .fs.on { display: block; }
      .hint.on ~ .fs { display: none; } /* the "New video" hint uses the same spot */
      .drop {
        position: absolute; inset: 8px; border: 3px dashed rgba(255,255,255,.9); border-radius: 12px;
        background: rgba(0,0,0,.45); display: none; align-items: center; justify-content: center; font-size: 20px;
      }
      .drop.on { display: flex; }
      .found {
        position: absolute; top: 12px; right: 12px; display: none; flex-direction: column; gap: 6px;
        pointer-events: auto; max-width: min(420px, calc(100% - 24px));
        background: rgba(20,20,20,.92); padding: 10px 10px 10px 12px; border-radius: 12px;
        font: 600 13px/1.3 system-ui, -apple-system, "Segoe UI", sans-serif; color: #fff;
      }
      .found.on { display: flex; }
      .found-head { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
      .found-row { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
      .found-name { flex-basis: 120px; }
      .found-name { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-weight: 500; opacity: .85; }
      .found-lang { font-size: 11px; text-transform: uppercase; background: #6d28d9; border-radius: 5px; padding: 1px 6px; }
      .found button {
        font: inherit; color: #fff; background: rgba(255,255,255,.16); border: 0;
        border-radius: 7px; padding: 4px 10px; cursor: pointer; white-space: nowrap;
      }
      .found button:hover { background: rgba(255,255,255,.28); }
      .found button.main { background: #7c3aed; }
      .found button.main:hover { background: #8b5cf6; }
      .found .x { background: transparent; padding: 2px 6px; }
      .found-msg { display: flex; flex-direction: column; align-items: flex-start; gap: 6px; font-weight: 500; font-size: 12px; }
      .found-msg > span { opacity: .85; }
      .found-msg .saved::before { content: "\\2713"; color: #86efac; font-weight: 700; margin-right: 6px; }
    `;
    subsEl = el('div', 'subs');
    toastEl = el('div', 'toast');
    hintEl = el('div', 'hint');
    hintEl.append(el('span', '', 'New video. Load subtitles for it?'));
    const restore = el('button', '', 'Restore previous');
    restore.addEventListener('click', restoreStashed);
    const close = el('button', '', '×');
    close.title = 'Dismiss';
    close.addEventListener('click', () => { stashed = null; hintEl.classList.remove('on'); });
    hintEl.append(restore, close);
    fsBtn = el('button', 'fs', '⛶ Fullscreen with subtitles (Alt+F)');
    fsBtn.addEventListener('click', (e) => { e.stopPropagation(); toggleFullscreen(); });
    dropEl = el('div', 'drop', 'Drop .srt or .vtt subtitles here');
    foundEl = el('div', 'found');
    siteNoteEl = el('div', 'site-note');
    const noteText = el('span', '');
    noteText.append(el('b', '', 'Two sets of subtitles. '), 'Turn the site\u2019s own subtitles off in its player (CC button).');
    const noteClose = el('button', '', '\u00d7');
    noteClose.title = 'Dismiss';
    noteClose.addEventListener('click', () => { siteDismissed = true; setSiteNote(siteSeen); });
    siteNoteEl.append(noteText, noteClose);
    shadow.append(style, subsEl, toastEl, hintEl, fsBtn, dropEl, foundEl, siteNoteEl);
    placeHost();
    useFont();
  }

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text) n.textContent = text;
    return n;
  }

  // Puts the overlay where it can be seen: inside the fullscreen element when
  // the site's player container is fullscreen, otherwise at the page root.
  function placeHost() {
    if (!host) return;
    const fe = document.fullscreenElement;
    let parent = document.documentElement;
    if (fe && video && fe !== video && containsDeep(fe, video)) {
      const root = video.getRootNode();
      parent = root instanceof ShadowRoot && containsDeep(fe, root.host) && fe.shadowRoot ? root : fe;
    }
    if (host.parentNode !== parent) parent.appendChild(host);
  }

  // Like Node.contains, but also looks through shadow roots.
  function containsDeep(ancestor, node) {
    let n = node;
    while (n) {
      if (n === ancestor) return true;
      n = n.parentNode || (n instanceof ShadowRoot ? n.host : null);
    }
    return false;
  }

  let toastTimer = 0;
  function toast(text, ms) {
    ensureHost();
    toastEl.textContent = text;
    toastEl.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('on'), ms || 1500);
    position(true);
  }

  // ---------- geometry ----------

  // Box of the actual picture inside the video element (without letterbox bars).
  function pictureRect(v) {
    const r = v.getBoundingClientRect();
    const vw = v.videoWidth, vh = v.videoHeight;
    const fit = getComputedStyle(v).objectFit;
    if (!vw || !vh || fit === 'fill' || fit === 'cover') return { left: r.left, top: r.top, width: r.width, height: r.height };
    const k = Math.min(r.width / vw, r.height / vh);
    const w = vw * k, h = vh * k;
    return { left: r.left + (r.width - w) / 2, top: r.top + (r.height - h) / 2, width: w, height: h };
  }

  function position(force) {
    if (!host || !video) return;
    const r = pictureRect(video);
    const geom = [r.left, r.top, r.width, r.height].map(Math.round).join(',');
    if (!force && geom === lastGeom) return;
    lastGeom = geom;
    const hs = host.style;
    hs.setProperty('left', Math.round(r.left) + 'px', 'important');
    hs.setProperty('top', Math.round(r.top) + 'px', 'important');
    hs.setProperty('width', Math.round(r.width) + 'px', 'important');
    hs.setProperty('height', Math.round(r.height) + 'px', 'important');
    SubRender.applyStyle(subsEl, settings, r.height, r.width);
  }

  function refreshStyle() {
    if (!subsEl) return;
    useFont();
    position(true);
    render(true);
  }

  // A Google font is only downloaded once the overlay is actually used on a page.
  function useFont() {
    if (!SubRender.isGoogle(settings.font)) return;
    SubRender.ensureFont(document, settings.font)
      .then(() => position(true))
      .catch(() => toast('Font "' + SubRender.googleName(settings.font) + '" could not load'));
  }

  // ---------- timing ----------

  // Cues active at time t (ms). Binary search, then look back for overlaps.
  function activeAt(t, list) {
    if (!list) list = cues;
    let lo = 0, hi = list.length - 1, last = -1;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (list[mid].start <= t) { last = mid; lo = mid + 1; } else hi = mid - 1;
    }
    const out = [];
    for (let i = last; i >= 0 && last - i < 30; i--) if (list[i].end > t) out.push(i);
    return out.reverse();
  }

  // YouTube marks its player with .ad-showing while an ad plays in the same video.
  function inAd() {
    const ad = !!(video && video.closest && video.closest('.ad-showing'));
    if (ad) lastAdAt = Date.now();
    return ad;
  }

  function render(force) {
    if (!subsEl || !video) return;
    let idx = [];
    const hide = !visible || !cues.length || inAd() || (video.paused && settings.onPause === 'hide');
    if (!hide) idx = activeAt(video.currentTime * 1000 - settings.offset);
    const key = idx.join(',');
    if (!force && key === lastKey) return;
    lastKey = key;
    SubRender.renderCues(subsEl, idx.map((i) => cues[i]));
    // The site draws its line a moment after ours, so look a little later.
    startSiteWatch();
    checkSiteText();
    clearTimeout(siteTimer);
    siteTimer = setTimeout(checkSiteText, 400);
  }

  function tick() {
    raf = 0;
    position(false);
    render(false);
    if (video && cues.length && !video.paused && !video.ended) raf = requestAnimationFrame(tick);
  }

  function kick() {
    if (!raf) raf = requestAnimationFrame(tick);
  }

  // ---------- attaching to a video ----------

  const VIDEO_EVENTS = ['play', 'playing', 'pause', 'seeking', 'seeked', 'ratechange', 'timeupdate', 'loadedmetadata'];
  let resizeObs = null;

  function attach(v) {
    if (video === v) return;
    detachVideo();
    video = v;
    lastSrc = v.currentSrc || v.src || '';
    for (const ev of VIDEO_EVENTS) v.addEventListener(ev, kick);
    v.addEventListener('loadstart', onSourceChange);
    v.addEventListener('emptied', onSourceChange);
    // The site may switch a caption track back on (for example when you pick another language).
    v.textTracks.addEventListener('change', () => { if (siteStyle) hideSiteSubs(true); });
    resizeObs = new ResizeObserver(() => position(false));
    resizeObs.observe(v);
    ensureHost();
    placeHost();
    lastKey = '';
    position(true);
    kick();
  }

  function detachVideo() {
    if (!video) return;
    for (const ev of VIDEO_EVENTS) video.removeEventListener(ev, kick);
    video.removeEventListener('loadstart', onSourceChange);
    video.removeEventListener('emptied', onSourceChange);
    if (resizeObs) resizeObs.disconnect();
    resizeObs = null;
    if (siteObs) siteObs.disconnect(); // the next video gets its own watcher
    siteObs = sitePlayer = null;
    video = null;
  }

  // While subtitles are loaded: once a second, check the video still exists
  // and still plays the same thing (single-page sites swap videos without reloading).
  function startWatch() {
    if (watchTimer) return;
    watchTimer = setInterval(() => {
      if (!cues.length && !stashed && !restorePending) return stopWatch();
      if (restorePending) return tryRestore();
      if (!video || !video.isConnected) {
        const next = pickVideo();
        if (next) {
          const sameSrc = (next.currentSrc || next.src) === lastSrc;
          attach(next);
          if (!sameSrc) onSourceChange();
        }
        return;
      }
      if ((video.currentSrc || video.src || '') !== lastSrc) onSourceChange();
      inAd();
    }, 1000);
  }

  function stopWatch() {
    clearInterval(watchTimer);
    watchTimer = 0;
  }

  function onSourceChange() {
    if (!video) return;
    const src = video.currentSrc || video.src || '';
    if (!src || src === lastSrc) return;
    lastSrc = src;
    // Ads in the same element change the source too; don't drop subtitles for them.
    if (inAd() || Date.now() - lastAdAt < 5000) return;
    if (!cues.length) return;
    stashed = { cues, file };
    clearSubs(true);
    ensureHost();
    hintEl.classList.add('on');
    setTimeout(() => hintEl && hintEl.classList.remove('on'), 10000);
  }

  function restoreStashed() {
    if (!stashed) return;
    cues = stashed.cues;
    file = stashed.file;
    stashed = null;
    hintEl.classList.remove('on');
    afterLoad();
  }

  // ---------- loading ----------

  function loadBytes(name, b64, encoding, targetVideo) {
    const bytes = SubLib.base64ToBytes(b64);
    const { text, encoding: used } = SubLib.decode(bytes, encoding || 'auto');
    const parsed = SubLib.parse(text);
    if (!parsed.length) return { ok: false, error: 'No subtitle lines found in this file.' };
    const v = targetVideo || pickVideo();
    if (!v) return { ok: false, error: 'No video found on this page.' };
    cues = parsed;
    file = { name, b64, encoding: encoding || 'auto', usedEncoding: used };
    autoLoaded = false;
    siteDismissed = false;
    original = null;
    translations.clear();
    stashed = null;
    if (hintEl) hintEl.classList.remove('on');
    attach(v);
    afterLoad();
    rememberFile();
    toast('Loaded ' + parsed.length + ' lines' + (settings.offset ? ' · Sync: ' + fmtOffset(settings.offset) : ''));
    return { ok: true, count: parsed.length, encoding: used };
  }

  function afterLoad() {
    hideSiteSubs(true);
    visible = true;
    lastKey = '';
    startWatch();
    enableMouse(true);
    position(true);
    render(true);
    kick();
    send({ type: 'subs-state', has: true });
  }

  function clearSubs(keepStash) {
    hideSiteSubs(false);
    stopSiteWatch();
    autoLoaded = false;
    cues = [];
    file = null;
    original = null;
    translations.clear();
    if (!keepStash) stashed = null;
    lastKey = '';
    if (subsEl) subsEl.replaceChildren();
    enableMouse(false);
    if (fsBtn) fsBtn.classList.remove('on');
    send({ type: 'subs-state', has: false });
  }

  // Restore the last file loaded on this exact page (after a reload).
  let restorePending = null;
  async function checkSessionRestore() {
    try {
      const key = pageKey();
      const got = await chrome.storage.session.get(key);
      if (got[key]) { restorePending = got[key]; startWatch(); tryRestore(); }
    } catch (e) { /* no session access */ }
  }
  function tryRestore() {
    if (!restorePending) return;
    const v = pickVideo();
    if (!v) return;
    const f = restorePending;
    restorePending = null;
    if (!f.original) return loadBytes(f.name, f.b64, f.encoding, v);
    // A translation was showing: bring back the original, then the saved translation (no new request).
    const r = loadBytes(f.original.name, f.original.b64, f.original.encoding, v);
    if (r.ok) showTranslation(f.translatedTo, SubLib.parse(SubLib.decode(SubLib.base64ToBytes(f.b64), 'utf-8').text), true);
  }

  // ---------- the site's own subtitles ----------

  // While our subtitles show, the site's own ones are hidden so they don't
  // double up: the browser's built-in caption layer always, plus the caption
  // layers of common web players. A player that draws captions some other way
  // keeps them; then you switch them off in the player.
  const SITE_SUBS_CSS = `
    video::-webkit-media-text-track-container { display: none !important; }
    .vjs-text-track-display, .shaka-text-container, .jw-captions, .jw-text-track-container,
    .bmpui-ui-subtitle-overlay, .theoplayer-texttracks, .fp-captions, .plyr__captions,
    .mejs__captions-layer, .dash-captions-container, .ytp-caption-window-container { visibility: hidden !important; }`;
  let siteStyle = null;
  let hiddenTracks = [];

  function hideSiteSubs(on) {
    if (on && cues.length) {
      if (!siteStyle) {
        siteStyle = document.createElement('style');
        siteStyle.textContent = SITE_SUBS_CSS;
        (document.head || document.documentElement).append(siteStyle);
      }
      // Tracks the browser draws itself: "hidden" still loads their lines (players keep working).
      for (const v of findVideos()) {
        for (const t of v.textTracks) if (t.mode === 'showing') { t.mode = 'hidden'; hiddenTracks.push(t); }
      }
    } else {
      if (siteStyle) siteStyle.remove();
      siteStyle = null;
      for (const t of hiddenTracks) if (t.mode === 'hidden') t.mode = 'showing';
      hiddenTracks = [];
    }
  }

  // Players that draw subtitles with their own code (Prima+ and many others).
  // The site shows the very file we caught, so we know its current line. The
  // first time that text shows up next to the video, its box is hidden and,
  // when the box has class names, a style rule hides every later box like it,
  // so new lines never paint. A watcher on the player also catches a new line
  // before the browser draws it. If something still shows (we couldn't hide
  // it), a note asks you to switch the site's subtitles off in its player.
  let siteTimer = 0;
  let siteSeen = false;      // the site's line is on screen right now
  let siteDismissed = false; // you closed the note (until the next file)
  let siteObs = null;        // watches the player for new caption lines
  let sitePlayer = null;     // the element it watches
  const siteRules = new Map(); // document or shadow root -> <style> with the hide rules
  const siteMarked = new Set(); // boxes hidden directly
  const squash = (s) => String(s || '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '');

  // The nearest ancestor of the video that is about as big as the video.
  function playerOf(v) {
    const vr = v.getBoundingClientRect();
    let player = v.parentElement;
    for (let i = 0; i < 6 && player && player.parentElement; i++) {
      const r = player.parentElement.getBoundingClientRect();
      if (r.width > vr.width * 1.3 || r.height > vr.height * 1.6) break;
      player = player.parentElement;
    }
    return player;
  }

  function startSiteWatch() {
    if (siteObs || !video) return;
    const player = sitePlayer = playerOf(video);
    if (!player) return;
    // Mutation callbacks run before the next paint, so a line hidden here never shows.
    siteObs = new MutationObserver(checkSiteText);
    siteObs.observe(player, SITE_WATCH);
  }
  // Text changes, new elements, and boxes shown by switching a class or style.
  const SITE_WATCH = { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['class', 'style', 'hidden'] };
  const watchedRoots = new WeakSet(); // shadow roots inside the player already watched
  const siteHiddenLog = []; // what was hidden, shown in the popup

  function stopSiteWatch() {
    if (siteObs) siteObs.disconnect();
    siteObs = sitePlayer = null;
    for (const st of siteRules.values()) st.remove();
    siteRules.clear();
    for (const el of siteMarked) el.style.removeProperty('visibility');
    siteMarked.clear();
    siteHiddenLog.length = 0;
    setSiteNote(false);
  }

  // A class selector for a caption box, without state classes that come and go.
  function boxSelector(el) {
    const cls = [...el.classList].filter((c) => !/^(is-|has-)?(active|visible|show(n|ing)?|hidden|on|off|open|in|out|enter|leave|fade.*)$/i.test(c)
      && !/[-_]\d+$/.test(c)); // numbered per line ("line-17"): would never match the next one
    return cls.length ? el.localName + cls.map((c) => '.' + CSS.escape(c)).join('') : '';
  }

  function hideBox(box) {
    box.style.setProperty('visibility', 'hidden', 'important');
    siteMarked.add(box);
    let sel = boxSelector(box);
    // No class of its own: name it through its parent, if the parent holds no controls.
    const p = box.parentElement;
    if (!sel && p && !p.querySelector('button, input, select, [role=slider]')) {
      const ps = boxSelector(p);
      if (ps) sel = ps + ' > ' + box.localName;
    }
    const label = (sel || box.localName + ' (no class)') + (box.getRootNode() instanceof ShadowRoot ? ' in shadow DOM' : '');
    if (!siteHiddenLog.includes(label)) siteHiddenLog.push(label);
    if (!sel) return;
    const root = box.getRootNode();
    let st = siteRules.get(root);
    if (!st) {
      st = document.createElement('style');
      siteRules.set(root, st);
      (root instanceof ShadowRoot ? root : (document.head || document.documentElement)).append(st);
    }
    const rule = sel + ' { visibility: hidden !important; }';
    if (!st.textContent.includes(rule)) st.textContent += rule + '\n';
  }

  function checkSiteText() {
    if (!video || !cues.length) return setSiteNote(false);
    const source = original ? original.cues : cues;
    // The site's own timing, without our sync offset; also the line just
    // starting, since the site may switch a moment before our clock says so.
    const t = video.currentTime * 1000;
    const idx = [...new Set(activeAt(t, source).concat(activeAt(t + 700, source)))];
    if (!idx.length) return; // nothing to compare between lines: keep the note as it is
    const player = sitePlayer || playerOf(video); // measured once per video, not on every change
    if (!player) return;
    let visible = false;
    for (const i of idx) {
      // The first line, clean: enough to recognise it, short enough to survive the site's own line breaks.
      const first = SubLib.toRuns(source[i].text).map((r) => r.text).join('').split('\n').find((l) => squash(l).length >= 3);
      const needle = squash(first).slice(0, 40);
      if (needle.length < 4) continue; // too short to be sure it is a caption ("Ano.")
      for (const el of textHolders(player, needle)) {
        // Hide it even while it is still invisible: players fade lines in or
        // reveal them by a class change a moment later.
        if (getComputedStyle(el).visibility === 'hidden') continue;
        // Climb a little while the parent holds nothing but this caption (so a
        // background box goes too), never up to anything with controls in it.
        let box = el;
        for (let k = 0; k < 3; k++) {
          const p = box.parentElement;
          if (!p || p === player || p.contains(video) || (host && p.contains(host))) break;
          if (squash(p.textContent) !== squash(box.textContent)) break;
          if (p.querySelector('button, input, select, a[href], [role=button], [role=slider], [tabindex]')) break;
          box = p;
        }
        hideBox(box);
        if (el.getClientRects().length && getComputedStyle(el).visibility !== 'hidden') visible = true;
      }
    }
    setSiteNote(visible);
  }

  function setSiteNote(on) {
    siteSeen = on;
    if (!siteNoteEl) return;
    siteNoteEl.classList.toggle('on', on && !siteDismissed);
  }

  // Smallest elements whose text contains the needle, also inside open shadow roots.
  function textHolders(root, needle) {
    const out = [];
    const walk = (node) => {
      for (const el of node.querySelectorAll('*')) {
        if (el === host || el === video) continue;
        if (el.shadowRoot) {
          // Changes inside a web component don't reach the player's watcher: watch it too.
          if (siteObs && !watchedRoots.has(el.shadowRoot)) { watchedRoots.add(el.shadowRoot); siteObs.observe(el.shadowRoot, SITE_WATCH); }
          walk(el.shadowRoot);
        }
        if (el.childElementCount > 8) continue;
        if (!squash(el.textContent).includes(needle)) continue;
        if ([...el.children].some((c) => squash(c.textContent).includes(needle))) continue; // a child holds it more tightly
        out.push(el);
      }
    };
    walk(root);
    return out.slice(0, 4);
  }

  const offHint = () => (siteSeen ? ' Turn the site\u2019s own subtitles off in its player.' : '');

  // ---------- translation ----------

  // Lines travel as HTML so <i>/<b> and line breaks survive the round trip.
  const toHtml = (raw) => SubLib.cleanText(raw).replace(/\n/g, '<br>');
  const fromHtml = (html) => String(html || '')
    .replace(/\s*<br\s*\/?>\s*/gi, '\n')
    .replace(/(<\/(?:i|b|u)>)\s+([.,!?;:\u2026])/g, '$1$2') // Google adds a space before punctuation after a tag
    .trim();

  async function translate(to) {
    if (!cues.length) return { ok: false, error: 'Nothing loaded.' };
    const base = original || { file, cues };
    let list = translations.get(to);
    if (!list) {
      toast('Translating ' + base.cues.length + ' lines to ' + SubSettings.languageName(to) + '\u2026', 15000);
      const res = await chrome.runtime.sendMessage({ type: 'translate', to, texts: base.cues.map((c) => toHtml(c.text)) })
        .catch((e) => ({ ok: false, error: e.message }));
      if (!res || !res.ok) {
        toast('Translation didn\u2019t work');
        return { ok: false, error: res ? res.error : 'Translation failed.' };
      }
      if (file !== base.file && !original) return { ok: false, error: 'Other subtitles were loaded meanwhile.' };
      list = base.cues.map((c, i) => ({ start: c.start, end: c.end, text: fromHtml(res.texts[i]) || c.text }));
    }
    showTranslation(to, list);
    return { ok: true, count: list.length };
  }

  // Swaps the lines on screen for a translation and keeps the original for "Show original".
  function showTranslation(to, list, quiet) {
    if (!list.length) return;
    if (!original) original = { file, cues };
    translations.set(to, list);
    cues = list;
    const name = original.file.name.replace(/\.(web)?vtt$|\.srt$/i, '') + '.' + to + '.srt';
    file = { name, b64: SubLib.bytesToBase64(new TextEncoder().encode(SubLib.toSRT(list))), encoding: 'utf-8', usedEncoding: 'utf-8',
      translatedTo: to, original: original.file };
    lastKey = '';
    render(true);
    rememberFile();
    if (!quiet) toast('Translated to ' + SubSettings.languageName(to), 3000);
  }

  function showOriginal() {
    if (!original) return;
    cues = original.cues;
    file = original.file;
    original = null;
    lastKey = '';
    render(true);
    rememberFile();
    toast('Original subtitles');
  }

  // ---------- fullscreen ----------

  document.addEventListener('fullscreenchange', () => {
    const fe = document.fullscreenElement;
    if (ownFullscreen && fe !== ownFullscreen.container) {
      video && (video.style.cssText = ownFullscreen.videoStyle);
      ownFullscreen = null;
    }
    if (!video || !cues.length) return;
    if (fe === video) bareFullscreen = true;
    else if (!fe && bareFullscreen) {
      bareFullscreen = false;
      setTimeout(() => toast('This site’s fullscreen hides subtitles. Use Alt+F instead.'), 300);
    }
    placeHost();
    position(true);
    render(true);
  });

  // Our own fullscreen: the video's parent element plus the overlay inside it.
  async function toggleFullscreen() {
    if (!video) return;
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(() => {});
      return;
    }
    const container = video.parentElement || (video.getRootNode() instanceof ShadowRoot ? video.getRootNode().host : null);
    if (!container) return;
    const videoStyle = video.style.cssText;
    try {
      await container.requestFullscreen();
      ownFullscreen = { container, videoStyle };
      for (const [k, v] of Object.entries({
        position: 'absolute', inset: '0', width: '100%', height: '100%', 'max-width': 'none',
        'max-height': 'none', 'object-fit': 'contain', transform: 'none', margin: '0',
      })) video.style.setProperty(k, v, 'important');
      fsBtn.classList.remove('on');
    } catch (e) {
      toast('Click the video once, then press Alt+F');
    }
  }

  // Show the fullscreen button briefly when the mouse moves over the video.
  let fsTimer = 0, mouseQueued = false;
  function onMouseMove(e) {
    if (mouseQueued || !video || !fsBtn || document.fullscreenElement) return;
    mouseQueued = true;
    requestAnimationFrame(() => {
      mouseQueued = false;
      const r = video.getBoundingClientRect();
      const inside = e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom;
      if (!inside) return;
      fsBtn.classList.add('on');
      clearTimeout(fsTimer);
      fsTimer = setTimeout(() => fsBtn.classList.remove('on'), 2000);
    });
  }
  function enableMouse(on) {
    document[on ? 'addEventListener' : 'removeEventListener']('mousemove', onMouseMove, { passive: true, capture: true });
  }

  // When paused, the loop is off, so follow layout changes from these events.
  window.addEventListener('resize', () => cues.length && position(true));
  window.addEventListener('scroll', () => cues.length && position(false), { capture: true, passive: true });

  // ---------- keyboard ----------

  function isTyping(e) {
    const t = e.composedPath ? e.composedPath()[0] : e.target;
    if (!t || !t.tagName) return false;
    if (t.isContentEditable) return true;
    if (t.tagName === 'TEXTAREA' || t.tagName === 'SELECT') return true;
    if (t.tagName === 'INPUT') return !/^(button|checkbox|radio|range|submit|reset|color|file|image)$/i.test(t.type);
    return false;
  }

  // Physical keys (event.code), so Option on a Mac doesn't change the match.
  function actionFor(e) {
    if (!e.altKey || e.ctrlKey || e.metaKey) return null;
    switch (e.code) {
      case 'BracketLeft': return { kind: 'offset', delta: e.shiftKey ? -1000 : -100 };
      case 'BracketRight': return { kind: 'offset', delta: e.shiftKey ? 1000 : 100 };
      case 'Digit0': return e.shiftKey ? null : { kind: 'offset-reset' };
      case 'KeyS': return e.shiftKey ? null : { kind: 'toggle' };
      case 'ArrowUp': return e.shiftKey ? null : { kind: 'move', delta: 10 };
      case 'ArrowDown': return e.shiftKey ? null : { kind: 'move', delta: -10 };
      case 'KeyF': return e.shiftKey ? null : { kind: 'fullscreen' };
      default: return null;
    }
  }

  window.addEventListener('keydown', (e) => {
    if (e.repeat && e.code === 'KeyF') return;
    const action = actionFor(e);
    if (!action || isTyping(e)) return;
    if (cues.length) runAction(action);
    else if (tabHasSubs) send({ type: 'forward-key', action });
    else return;
    e.preventDefault();
    e.stopImmediatePropagation();
  }, true);

  function fmtOffset(ms) {
    return (ms > 0 ? '+' : ms < 0 ? '−' : '') + (Math.abs(ms) / 1000).toFixed(1) + ' s';
  }

  async function runAction(a) {
    if (a.kind === 'offset' || a.kind === 'offset-reset') {
      // Update locally first so fast repeated presses add up before the save lands.
      settings.offset = SubSettings.clamp('offset', a.kind === 'offset' ? settings.offset + a.delta : 0);
      SubSettings.save({ offset: settings.offset });
      toast('Sync: ' + fmtOffset(settings.offset));
      render(true);
    } else if (a.kind === 'toggle') {
      visible = !visible;
      render(true);
      toast(visible ? 'Subtitles on' : 'Subtitles off');
    } else if (a.kind === 'move') {
      settings.bottom = SubSettings.clamp('bottom', settings.bottom + a.delta);
      SubSettings.save({ bottom: settings.bottom });
      position(true);
      toast('Position: ' + settings.bottom + ' px');
    } else if (a.kind === 'fullscreen') {
      toggleFullscreen();
    }
  }

  // ---------- drag and drop ----------

  function videoAt(x, y) {
    return findVideos().find((v) => {
      const r = v.getBoundingClientRect();
      return r.width > 50 && x >= r.left && x <= r.right && y >= r.top && y <= r.bottom;
    });
  }

  let dropVideo = null;
  document.addEventListener('dragover', (e) => {
    if (!e.dataTransfer || ![...e.dataTransfer.types].includes('Files')) return;
    const v = videoAt(e.clientX, e.clientY);
    if (!v) return hideDrop();
    e.preventDefault();
    e.stopPropagation();
    e.dataTransfer.dropEffect = 'copy';
    if (dropVideo !== v) {
      dropVideo = v;
      if (video !== v) { if (!cues.length) attach(v); }
      ensureHost();
      dropEl.classList.add('on');
      position(true);
    }
  }, true);
  document.addEventListener('dragleave', (e) => { if (!e.relatedTarget) hideDrop(); }, true);
  function hideDrop() {
    dropVideo = null;
    if (dropEl) dropEl.classList.remove('on');
  }

  document.addEventListener('drop', async (e) => {
    if (!dropVideo) return;
    const v = dropVideo;
    hideDrop();
    e.preventDefault();
    e.stopPropagation();
    const f = e.dataTransfer.files[0];
    if (!f || !/\.(srt|vtt)$/i.test(f.name)) return toast('Drop an .srt or .vtt file');
    const bytes = new Uint8Array(await f.arrayBuffer());
    pinned = v;
    const res = loadBytes(f.name, SubLib.bytesToBase64(bytes), 'auto', v);
    if (!res.ok) toast(res.error);
  }, true);

  // ---------- "Subtitles found" card ----------

  // Subtitle files the page just loaded (seen by the background worker),
  // offered with one-click buttons right on the video.
  // The card waits until you actually watch something: a video playing with
  // sound. Feeds like Reddit preload and autoplay muted previews, whose
  // subtitle tracks would otherwise pop up while you only scroll. Files seen
  // more than a minute before that are dropped (they belong to other posts).
  const found = [];
  const waiting = []; // { item, t }
  let foundTimer = 0;
  const WAIT_MS = 60000;

  const watched = () => findVideos().find((v) => isPlaying(v) && !v.muted && v.volume > 0 && area(v) > 0);

  const shownIds = new Set(); // found files already offered or used here, so retries don't repeat them
  let waitTimer = 0;

  function showFound(item) {
    if (!findVideos().length) return false;
    if (shownIds.has(item.id)) return true;
    if (!waiting.some((w) => w.item.id === item.id)) waiting.push({ item, t: Date.now() });
    flushFound();
    // Not watching yet (the player still starting, muted, buffering): check every
    // second too, in case the "playing" event already passed.
    if (waiting.length && !waitTimer) {
      waitTimer = setInterval(() => {
        flushFound();
        if (!waiting.length || waiting.every((w) => Date.now() - w.t > WAIT_MS)) { clearInterval(waitTimer); waitTimer = 0; }
      }, 1000);
    }
    return true;
  }

  function flushFound() {
    if (!waiting.length) return;
    const v = watched();
    if (!v) return;
    const fresh = waiting.splice(0).filter((w) => Date.now() - w.t < WAIT_MS);
    if (!fresh.length) return;
    for (const w of fresh) shownIds.add(w.item.id);
    if (!video) attach(v);
    ensureHost();
    for (const w of fresh) if (!found.some((f) => f.id === w.item.id)) found.unshift(w.item);
    found.length = Math.min(found.length, 3);
    // Automatic mode: the newest file goes straight onto the video, translated.
    // A file you loaded yourself is never replaced.
    if (prefs.autoTranslate && (!cues.length || autoLoaded)) autoShow(fresh[fresh.length - 1].item);
    else renderFound();
    position(true);
  }

  // No card here: the toast at the top says "Translating…" and then
  // "Translated to …". Only a failure opens the card, with its buttons.
  async function autoShow(item) {
    const lang = SubSettings.languageName(prefs.translateTo);
    toast('Translating to ' + lang + '\u2026', 15000);
    let message;
    try {
      const res = await chrome.runtime.sendMessage({ type: 'fetch-item', id: item.id });
      if (!res || !res.ok) throw new Error(res ? res.error : 'Failed.');
      const r = loadBytes(res.name, res.b64, 'auto', video || pickVideo());
      if (!r.ok) throw new Error(r.error);
      autoLoaded = true;
      const t = await translate(prefs.translateTo);
      if (!t.ok) throw new Error(t.error);
      return;
    } catch (e) {
      message = 'Automatic translation didn\u2019t work: ' + e.message;
    }
    renderFound(message);
  }

  // Media events don't bubble, so listen in the capture phase.
  document.addEventListener('playing', flushFound, true);
  document.addEventListener('volumechange', flushFound, true);

  function renderFound(message) {
    const head = el('div', 'found-head');
    head.append(el('span', '', found.length > 1 ? 'Subtitles found on this page' : 'Subtitles found'));
    const close = el('button', 'x', '×');
    close.title = 'Close';
    close.addEventListener('click', hideFound);
    head.append(close);
    const rows = found.map((item) => {
      const row = el('div', 'found-row');
      if (item.lang) row.append(el('span', 'found-lang', item.lang));
      const episode = window === window.top ? pageTitle() : '';
      const name = el('span', 'found-name', episode || item.name);
      name.title = episode ? episode + ' (' + item.name + ')' : item.name;
      const dl = el('button', 'main', 'Download .srt');
      dl.addEventListener('click', () => foundAction(dl, 'Download .srt', { type: 'convert-item', id: item.id, format: 'srt' },
        (res) => {
          SubLib.saveText(res.text, res.filename);
          return { text: 'Saved to Downloads (' + res.count + ' lines)', translate: true, saved: true };
        }));
      const use = el('button', '', 'Show over video');
      use.addEventListener('click', () => foundAction(use, 'Show over video', { type: 'fetch-item', id: item.id }, (res) => {
        const r = loadBytes(res.name, res.b64, 'auto', video || pickVideo());
        if (!r.ok) throw new Error(r.error);
        return 'Showing ' + r.count + ' lines.' + offHint();
      }));
      const tr = el('button', '', 'Translate to ' + SubSettings.languageName(prefs.translateTo));
      tr.title = 'Shows these subtitles over the video, translated by Google Translate. Change the language in the extension popup.';
      tr.addEventListener('click', () => foundAction(tr, tr.textContent, { type: 'fetch-item', id: item.id }, async (res) => {
        const r = loadBytes(res.name, res.b64, 'auto', video || pickVideo());
        if (!r.ok) throw new Error(r.error);
        const t = await translate(prefs.translateTo);
        if (!t.ok) throw new Error(t.error);
        return 'Showing ' + t.count + ' lines in ' + SubSettings.languageName(prefs.translateTo) + '.' + offHint();
      }));
      row.append(name, dl, use, tr);
      return row;
    });
    foundEl.replaceChildren(head, ...rows);
    if (message) {
      const line = el('div', 'found-msg');
      line.append(el('span', message.saved ? 'saved' : '', message.text || message));
      if (message.translate) {
        const tr = el('button', '', 'translate-subtitles.com \u2197');
        tr.title = 'Opens translate-subtitles.com. Upload the downloaded file there.';
        tr.addEventListener('click', () => send({ type: 'open-translator' }));
        line.append(tr);
      }
      foundEl.append(line);
    }
    foundEl.classList.add('on');
    clearTimeout(foundTimer);
    foundTimer = setTimeout(hideFound, message ? 12000 : 20000);
  }

  async function foundAction(button, label, msg, done) {
    button.disabled = true;
    button.textContent = '…';
    let message;
    try {
      const res = await chrome.runtime.sendMessage(msg);
      if (!res || !res.ok) throw new Error(res ? res.error : 'Failed.');
      message = await done(res);
    } catch (e) {
      message = 'Didn’t work: ' + e.message;
    }
    renderFound(message);
  }

  function hideFound() {
    clearTimeout(foundTimer);
    if (foundEl) foundEl.classList.remove('on');
    found.length = 0;
  }

  // ---------- popup / background messages ----------

  function videoList() {
    const current = video && cues.length ? video : pickVideo();
    return findVideos().map((v, index) => {
      const r = v.getBoundingClientRect();
      const tracks = [...v.textTracks].map((t, ti) => ({
        index: ti, label: t.label, language: t.language, kind: t.kind,
        count: t.cues ? t.cues.length : 0,
        preview: t.cues && t.cues.length ? String(t.cues[0].text || '').split('\n')[0] : '',
      })).filter((t) => t.count > 0);
      return {
        index, width: Math.round(r.width), height: Math.round(r.height), visible: area(v) > 0,
        playing: isPlaying(v), current: v === current, tracks,
      };
    }).filter((x) => x.visible || x.tracks.length);
  }

  // The episode or film name, for the found-subtitles cards. Players that
  // fill the system media controls know it best, then the page's share title,
  // then the tab title without a trailing " | Site name".
  function pageTitle() {
    let t = '';
    try { t = (navigator.mediaSession && navigator.mediaSession.metadata && navigator.mediaSession.metadata.title) || ''; } catch (e) { /* ignore */ }
    if (!t) {
      const og = document.querySelector('meta[property="og:title"], meta[name="twitter:title"]');
      t = (og && og.content) || document.title || '';
    }
    const host = location.hostname.replace(/[^a-z0-9]/gi, '').toLowerCase();
    const parts = t.split(/\s+[|\u2013\u2014\-\u00b7]\s+/);
    if (parts.length > 1) {
      const last = parts[parts.length - 1].replace(/[^a-z0-9]/gi, '').toLowerCase();
      if (last && host.includes(last)) parts.pop();
    }
    return parts.join(' \u00b7 ').replace(/\s+/g, ' ').trim().slice(0, 120);
  }

  function report() {
    return {
      title: pageTitle(),
      url: location.href,
      host: location.hostname,
      top: window === window.top,
      videos: videoList(),
      siteHidden: siteHiddenLog.slice(0, 4),
      siteVisible: siteSeen,
      loaded: cues.length ? {
        name: (original ? original.file : file).name, count: cues.length,
        encoding: (original ? original.file : file).encoding, usedEncoding: (original ? original.file : file).usedEncoding,
        translatedTo: original ? file.translatedTo : '',
      } : null,
    };
  }

  // Cues from the video's own text tracks (method 1 of capture), as WebVTT text.
  function trackAsVtt(videoIndex, trackIndex) {
    const v = findVideos()[videoIndex];
    const t = v && v.textTracks[trackIndex];
    if (!t || !t.cues) return null;
    const list = [...t.cues].map((c) => ({ start: Math.round(c.startTime * 1000), end: Math.round(c.endTime * 1000), text: c.text || '' }));
    return SubLib.toVTT(list);
  }

  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    switch (msg.type) {
      case 'load': {
        const v = msg.videoIndex != null ? findVideos()[msg.videoIndex] : null;
        if (v) pinned = v;
        reply(loadBytes(msg.name, msg.b64, msg.encoding, v));
        return;
      }
      case 'set-encoding': {
        if (!file) return reply({ ok: false, error: 'Nothing loaded.' });
        const src = original ? original.file : file; // a new encoding starts again from the original
        reply(loadBytes(src.name, src.b64, msg.encoding, video));
        return;
      }
      case 'use-font':
        // The popup waits for this to say "on the video".
        SubRender.ensureFont(document, msg.font)
          .then(() => { position(true); reply({ ok: true }); }, (e) => reply({ ok: false, error: e.message }));
        return true;
      case 'clear':
        clearSubs();
        try { chrome.storage.session.remove(pageKey()); } catch (e) { /* ignore */ }
        reply({ ok: true });
        return;
      case 'translate':
        translate(msg.to).then(reply);
        return true;
      case 'show-original':
        showOriginal();
        reply({ ok: true });
        return;
      case 'export':
        reply(file ? { name: file.name, b64: file.b64, encoding: file.encoding } : null);
        return;
      case 'select-video': {
        const v = findVideos()[msg.index];
        if (!v) return reply({ ok: false });
        pinned = v;
        if (cues.length) attach(v);
        reply({ ok: true });
        return;
      }
      case 'track-vtt':
        reply({ text: trackAsVtt(msg.videoIndex, msg.trackIndex) });
        return;
      case 'run-action':
        if (cues.length) runAction(msg.action);
        return;
      case 'subs-found':
        reply({ shown: showFound(msg.item) });
        return;
      case 'tab-subs':
        tabHasSubs = msg.has;
        return;
      case 'fetch-url':
        // Fallback download from inside the page, with the page's own cookies.
        fetch(msg.url, { credentials: 'include' })
          .then((r) => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.arrayBuffer(); })
          .then((buf) => reply({ ok: true, b64: SubLib.bytesToBase64(new Uint8Array(buf)) }))
          .catch((e) => reply({ ok: false, error: String(e.message || e) }));
        return true;
    }
  });

  window.__subOverlay = { report };
  checkSessionRestore();
  // Subtitles the player loaded before this script started (a busy page can take
  // seconds to get here): offer them now instead of losing them.
  if (window === window.top || findVideos().length) {
    send({ type: 'recent-found' }).then((items) => { for (const item of items || []) showFound(item); });
  }
})();
